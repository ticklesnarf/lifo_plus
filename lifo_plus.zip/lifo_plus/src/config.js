// src/config.js
import 'dotenv/config';
import { parseProductIds, getProduct } from './products.js';

function requireEnv(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

function envInt(name, def) {
  const v = process.env[name];
  if (v === undefined || v === '') return def;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`Invalid number for ${name}: ${v}`);
  return Math.trunc(n);
}

function envFloat(name, def) {
  const v = process.env[name];
  if (v === undefined || v === '') return def;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`Invalid number for ${name}: ${v}`);
  return n;
}

function envBool(name, def) {
  const v = process.env[name];
  if (v === undefined || v === '') return def;
  return ['1', 'true', 'yes', 'y', 'on'].includes(String(v).toLowerCase());
}

function envBigInt(name, def) {
  const v = process.env[name];
  if (v === undefined || v === '') return def;
  try {
    return BigInt(v);
  } catch {
    throw new Error(`Invalid bigint for ${name}: ${v}`);
  }
}

function normalizePrivateKey(key) {
  let k = key.trim();
  if (!k.startsWith('0x')) {
    k = '0x' + k;
  }
  return k;
}

export const config = {
  // Required
  privateKey: normalizePrivateKey(requireEnv('PRIVATE_KEY')),

  // Nado / chain selection
  network: (process.env.NADO_NETWORK || 'mainnet').toLowerCase(), // mainnet | testnet
  subaccountName: process.env.SUBACCOUNT_NAME || 'default',

  // Multi-product trading
  // PRODUCT_IDS: comma-separated list of product IDs to trade (e.g., "2,8" for BTC and SOL)
  // If not set, falls back to single PRODUCT_ID
  productIds: process.env.PRODUCT_IDS
    ? parseProductIds(process.env.PRODUCT_IDS)
    : [envInt('PRODUCT_ID', 2)],

  // Legacy single product (used if PRODUCT_IDS not set)
  productId: envInt('PRODUCT_ID', 2),

  // Time Zone Strategy Settings
  timezone: process.env.TIMEZONE || 'America/New_York',
  marketOpenHour: envInt('MARKET_OPEN_HOUR', 9),
  marketOpenMinute: envInt('MARKET_OPEN_MINUTE', 29),
  marketCloseHour: envInt('MARKET_CLOSE_HOUR', 16),
  marketCloseMinute: envInt('MARKET_CLOSE_MINUTE', 1),

  // Execution
  iocSlippageBps: envInt('IOC_SLIPPAGE_BPS', 100), // 1% slippage for market orders

  // Multi-Position Tiers (up to 3 concurrent positions with different leverage)
  enableMultiPosition: envBool('ENABLE_MULTI_POSITION', true),

  // Position Tier 1 (Primary - high leverage, quick scalp)
  tier1TargetLeverage: envFloat('TIER1_TARGET_LEVERAGE', 10),
  tier1MaxLeverage: envFloat('TIER1_MAX_LEVERAGE', 15),
  tier1Enabled: envBool('TIER1_ENABLED', true),
  tier1ProfitTargetPct: envFloat('TIER1_PROFIT_TARGET_PCT', 0.5),   // 0.5% target
  tier1TrailingStopPct: envFloat('TIER1_TRAILING_STOP_PCT', 0.25), // 0.25% trailing

  // Position Tier 2 (Secondary - medium hold)
  tier2TargetLeverage: envFloat('TIER2_TARGET_LEVERAGE', 2),
  tier2MaxLeverage: envFloat('TIER2_MAX_LEVERAGE', 3),
  tier2Enabled: envBool('TIER2_ENABLED', true),
  tier2ProfitTargetPct: envFloat('TIER2_PROFIT_TARGET_PCT', 1.5),  // 1.5% target
  tier2TrailingStopPct: envFloat('TIER2_TRAILING_STOP_PCT', 0.5), // 0.5% trailing

  // Position Tier 3 (Tertiary - longer hold)
  tier3TargetLeverage: envFloat('TIER3_TARGET_LEVERAGE', 2),
  tier3MaxLeverage: envFloat('TIER3_MAX_LEVERAGE', 3),
  tier3Enabled: envBool('TIER3_ENABLED', true),
  tier3ProfitTargetPct: envFloat('TIER3_PROFIT_TARGET_PCT', 3.0),  // 3% target
  tier3TrailingStopPct: envFloat('TIER3_TRAILING_STOP_PCT', 1.0), // 1% trailing

  // Legacy single-position config (used if ENABLE_MULTI_POSITION=false)
  targetLeverage: envFloat('TARGET_LEVERAGE', 10),
  maxLeverage: envFloat('MAX_LEVERAGE', 15),
  tradeUsdNotional: process.env.TRADE_USD_NOTIONAL ? envFloat('TRADE_USD_NOTIONAL', 0) : null,

  minOrderSizeX18: envBigInt('MIN_ORDER_SIZE_X18', 250_000_000_000_000n),
  sizeIncrementX18: envBigInt('SIZE_INCREMENT_X18', 100_000_000_000_000n),
  priceIncrementX18: envBigInt('PRICE_INCREMENT_X18', 0n),

  // Profit Taking
  profitTargetPct: envFloat('PROFIT_TARGET_PCT', 1.0),     // 1% profit target
  trailingStopPct: envFloat('TRAILING_STOP_PCT', 0.5),     // 0.5% trailing stop
  enableTrailingStop: envBool('ENABLE_TRAILING_STOP', true),
  tpZoneHoursThreshold: envFloat('TP_ZONE_HOURS_THRESHOLD', 6), // Skip zone flip if profitable and <6h to next flip

  // Behavior toggles
  dryRun: envBool('DRY_RUN', true),
  balanceFloorUsd: envFloat('BALANCE_FLOOR_USD', 175),
  skipUSHolidays: envBool('SKIP_US_HOLIDAYS', true),
  holdIfProfitable: envBool('HOLD_IF_PROFITABLE', true), // Skip zone flip if in TP zone

  // Adaptive Learning
  enableAdaptiveLearning: envBool('ENABLE_ADAPTIVE_LEARNING', true),
  learningLookbackDays: envInt('LEARNING_LOOKBACK_DAYS', 30),

  // Loop
  loopDelayMs: envInt('LOOP_DELAY_MS', 200),
  restPollIntervalMs: envInt('REST_POLL_INTERVAL_MS', 1500),

  // Logging
  logLevel: (process.env.LOG_LEVEL || 'info').toLowerCase(),
};

// Validation
if (config.subaccountName.length > 12) {
  throw new Error('SUBACCOUNT_NAME must be <= 12 bytes (ASCII recommended).');
}
if (!['mainnet', 'testnet'].includes(config.network)) {
  throw new Error('NADO_NETWORK must be "mainnet" or "testnet".');
}
if (config.targetLeverage <= 0 || config.maxLeverage <= 0 || config.maxLeverage < config.targetLeverage) {
  throw new Error('Invalid leverage config. Ensure MAX_LEVERAGE >= TARGET_LEVERAGE > 0.');
}
if (config.profitTargetPct <= 0) {
  throw new Error('PROFIT_TARGET_PCT must be > 0.');
}
if (config.trailingStopPct <= 0 || config.trailingStopPct >= config.profitTargetPct) {
  throw new Error('TRAILING_STOP_PCT must be > 0 and < PROFIT_TARGET_PCT.');
}
