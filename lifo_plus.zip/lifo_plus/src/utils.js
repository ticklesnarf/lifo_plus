// src/utils.js

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function nowSeconds() {
  return Math.floor(Date.now() / 1000);
}

export function bigintAbs(x) {
  return x < 0n ? -x : x;
}

/**
 * Round an x18 quantity down to the nearest increment.
 */
export function roundDownToIncrementX18(amountX18, incrementX18) {
  if (incrementX18 <= 0n) return amountX18;
  return (amountX18 / incrementX18) * incrementX18;
}

/**
 * Round an x18 quantity up to the nearest increment.
 */
export function roundUpToIncrementX18(amountX18, incrementX18) {
  if (incrementX18 <= 0n) return amountX18;
  const div = amountX18 / incrementX18;
  const mod = amountX18 % incrementX18;
  return mod === 0n ? amountX18 : (div + 1n) * incrementX18;
}

/**
 * Convert a fixed-point x18 integer (as string or bigint) to a human decimal string.
 * Example: 50000e18 -> "50000"
 */
export function x18ToDecimalString(x18) {
  const v = typeof x18 === 'bigint' ? x18 : BigInt(x18);
  const scale = 10n ** 18n;
  const intPart = v / scale;
  const fracPart = v % scale;
  if (fracPart === 0n) return intPart.toString();
  let frac = fracPart.toString().padStart(18, '0');
  // trim trailing zeros for readability
  frac = frac.replace(/0+$/, '');
  return `${intPart.toString()}.${frac}`;
}

/**
 * Parse a decimal string into a JS Number (used only for price calculations in USD space).
 * NOTE: Do not use this for on-chain precise math; use BigInt where required.
 */
export function toNumberSafe(x) {
  if (typeof x === 'number') return x;
  return Number(x);
}

/**
 * Clamp number between min and max.
 */
export function clamp(x, min, max) {
  return Math.max(min, Math.min(max, x));
}
