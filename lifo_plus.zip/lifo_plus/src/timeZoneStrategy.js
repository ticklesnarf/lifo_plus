// src/timeZoneStrategy.js
import { packOrderAppendix } from '@nadohq/client';
import cron from 'node-cron';

import { config } from './config.js';
import { log, safeStringify } from './logger.js';
import { getSubaccountState } from './nadoClient.js';
import { StateManager } from './stateManager.js';
import { getProduct, getProductSymbol } from './products.js';
import {
  setTimezoneConfig,
  nowInTimezone,
  getZoneSide,
  getZoneName,
  getNextZoneFlipInfo,
  hoursUntilNextZoneFlip,
  formatTime,
} from './timezone.js';
import { isMarketDay, getNonMarketDayReason, setHolidayTimezone } from './holidays.js';
import {
  sleep,
  nowSeconds,
  bigintAbs,
  roundDownToIncrementX18,
  roundUpToIncrementX18,
  x18ToDecimalString,
  clamp,
} from './utils.js';

const ONE_E18 = 10n ** 18n;

/**
 * Position Tier - tracks a single position within a leverage tier
 */
class PositionTier {
  constructor(tierId, targetLeverage, maxLeverage, enabled, profitTargetPct, trailingStopPct) {
    this.tierId = tierId;
    this.targetLeverage = targetLeverage;
    this.maxLeverage = maxLeverage;
    this.enabled = enabled;

    // Per-tier profit targets (fall back to global config if not specified)
    this.profitTargetPct = profitTargetPct ?? config.profitTargetPct;
    this.trailingStopPct = trailingStopPct ?? config.trailingStopPct;

    // Position state
    this.positionX18 = 0n;
    this.entryPriceX18 = 0n;
    this.peakPriceX18 = 0n;
    this.side = null;
    this.entryTime = null;

    // TP Zone tracking
    this.tpZone = {
      active: false,
      peakProfitPct: 0,
      enteredAt: null,
    };
  }

  isFlat() {
    return this.positionX18 === 0n;
  }

  isLong() {
    return this.positionX18 > 0n;
  }

  isShort() {
    return this.positionX18 < 0n;
  }

  getCurrentSide() {
    if (this.isLong()) return 'buy';
    if (this.isShort()) return 'sell';
    return null;
  }

  reset() {
    this.positionX18 = 0n;
    this.entryPriceX18 = 0n;
    this.peakPriceX18 = 0n;
    this.side = null;
    this.entryTime = null;
    this.tpZone = { active: false, peakProfitPct: 0, enteredAt: null };
  }

  toJSON() {
    return {
      tierId: this.tierId,
      targetLeverage: this.targetLeverage,
      maxLeverage: this.maxLeverage,
      enabled: this.enabled,
      profitTargetPct: this.profitTargetPct,
      trailingStopPct: this.trailingStopPct,
      positionX18: this.positionX18.toString(),
      entryPriceX18: this.entryPriceX18.toString(),
      side: this.side,
      entryTime: this.entryTime,
      tpZone: this.tpZone,
    };
  }

  fromJSON(data) {
    if (data.positionX18) this.positionX18 = BigInt(data.positionX18);
    if (data.entryPriceX18) this.entryPriceX18 = BigInt(data.entryPriceX18);
    if (data.peakPriceX18) this.peakPriceX18 = BigInt(data.peakPriceX18);
    this.side = data.side;
    this.entryTime = data.entryTime;
    if (data.tpZone) this.tpZone = data.tpZone;
  }
}

/**
 * Convert side to signed amount
 */
function sideToSignedAmountX18(side, amountAbsX18) {
  if (side === 'buy') return amountAbsX18;
  if (side === 'sell') return -amountAbsX18;
  throw new Error(`Invalid side: ${side}`);
}

/**
 * Compute IOC price with slippage for market-style orders
 */
function computeIocPriceX18(side, bbo) {
  const bidX18 = BigInt(bbo.bidPriceX18 || '0');
  const askX18 = BigInt(bbo.askPriceX18 || '0');

  if (bidX18 <= 0n || askX18 <= 0n) {
    throw new Error('Invalid BBO for IOC price computation');
  }

  const slippageBps = BigInt(config.iocSlippageBps);
  const bpsDen = 10_000n;

  if (side === 'buy') {
    const raw = (askX18 * (bpsDen + slippageBps)) / bpsDen;
    if (config.priceIncrementX18 > 0n) {
      return roundUpToIncrementX18(raw, config.priceIncrementX18);
    }
    return raw;
  } else {
    const raw = (bidX18 * (bpsDen - slippageBps)) / bpsDen;
    if (config.priceIncrementX18 > 0n) {
      return roundDownToIncrementX18(raw, config.priceIncrementX18);
    }
    return raw;
  }
}

function computeIocPrice(side, bbo) {
  const iocPriceX18 = computeIocPriceX18(side, bbo);
  return x18ToDecimalString(iocPriceX18);
}

/**
 * TimeZoneStrategy - Bitcoin9to5 style time-based trading with MULTI-POSITION support
 *
 * Strategy:
 * - SHORT during US market hours (9:29 AM - 4:01 PM ET)
 * - LONG outside market hours
 * - Up to 3 concurrent positions with different leverage tiers
 * - 1% profit target with 0.5% trailing stop per position
 */
export class TimeZoneStrategy {
  constructor({ nadoClient, subaccount, subscriptions, productId }) {
    this.nadoClient = nadoClient;
    this.subaccount = subaccount;
    this.subscriptions = subscriptions;

    // Product configuration
    this.productId = productId || config.productId;
    this.product = getProduct(this.productId);
    this.productSymbol = getProductSymbol(this.productId);

    // Product-specific sizing (use product defaults or config overrides)
    this.minOrderSizeX18 = this.product?.minSize || config.minOrderSizeX18;
    this.sizeIncrementX18 = this.product?.sizeIncrement || config.sizeIncrementX18;

    // Initialize timezone config
    setTimezoneConfig(config);
    setHolidayTimezone(config.timezone);

    // State management - use product-specific state file
    this.stateManager = new StateManager(this.productId);
    this.state = this.stateManager.loadBotState();

    // Market data
    this.lastBbo = null;

    // Initialize position tiers
    this._initializePositionTiers();

    // Total position tracking (sum of all tiers)
    this.totalPositionX18 = 0n;

    // Pending orders
    this.pending = new Map();
    this.inFlight = false;

    // Control flags
    this._tradingHalted = false;
    this._lastBalanceCheckMs = 0;
    this._lastReconcileMs = 0;
    this._reconcileMismatchCount = 0;
    this._scheduledJobs = [];

    // Stats
    this.stats = {
      startTime: Date.now(),
      fills: 0,
      notionalUsd: 0,
      baseQty: 0,
      wins: 0,
      losses: 0,
    };

    this._wireEvents();
  }

  _initializePositionTiers() {
    this.tiers = [];

    if (config.enableMultiPosition) {
      // Tier 1: Primary (high leverage, quick scalp)
      if (config.tier1Enabled) {
        this.tiers.push(new PositionTier(
          1, config.tier1TargetLeverage, config.tier1MaxLeverage, true,
          config.tier1ProfitTargetPct, config.tier1TrailingStopPct
        ));
      }
      // Tier 2: Secondary (medium hold)
      if (config.tier2Enabled) {
        this.tiers.push(new PositionTier(
          2, config.tier2TargetLeverage, config.tier2MaxLeverage, true,
          config.tier2ProfitTargetPct, config.tier2TrailingStopPct
        ));
      }
      // Tier 3: Tertiary (longer hold)
      if (config.tier3Enabled) {
        this.tiers.push(new PositionTier(
          3, config.tier3TargetLeverage, config.tier3MaxLeverage, true,
          config.tier3ProfitTargetPct, config.tier3TrailingStopPct
        ));
      }
    } else {
      // Single position mode (legacy) - uses global profit targets
      this.tiers.push(new PositionTier(1, config.targetLeverage, config.maxLeverage, true));
    }

    log.info('Position tiers initialized', {
      multiPosition: config.enableMultiPosition,
      tierCount: this.tiers.length,
      tiers: this.tiers.map(t => ({
        id: t.tierId,
        leverage: t.targetLeverage + 'x',
        profitTarget: t.profitTargetPct + '%',
        trailingStop: t.trailingStopPct + '%',
      })),
    });
  }

  _wireEvents() {
    this.subscriptions.on('bbo', (bbo) => {
      // Only process BBO for this product
      if (bbo.productId !== this.productId) return;

      this.lastBbo = bbo;
      this._checkAllProfitTargets();
    });

    this.subscriptions.on('fill', (fill) => {
      // Only process fills for this product
      if (fill.product_id !== this.productId) return;

      try {
        this._onFill(fill);
      } catch (err) {
        log.warn('Error handling fill', { error: String(err?.message || err), product: this.productSymbol });
      }
    });
  }

  // ==================== Order Execution ====================

  async _placeOrder({ orderExecutionType, side, amountAbsX18, price, reduceOnly }) {
    if (config.dryRun) {
      log.warn('DRY_RUN: Order blocked', {
        orderExecutionType,
        side,
        amountAbsX18: amountAbsX18.toString(),
        price,
        reduceOnly,
      });
      throw new Error('DRY_RUN mode - trading disabled');
    }

    const appendix = packOrderAppendix({ orderExecutionType, reduceOnly });
    const orderAmount = sideToSignedAmountX18(side, amountAbsX18);

    const order = {
      subaccountOwner: this.subaccount.subaccountOwner,
      subaccountName: this.subaccount.subaccountName,
      expiration: nowSeconds() + 60,
      appendix,
      price,
      amount: orderAmount,
    };

    log.info('Placing order', {
      product: this.productSymbol,
      type: orderExecutionType,
      side,
      amount: x18ToDecimalString(amountAbsX18),
      price,
      reduceOnly,
    });

    const res = await this.nadoClient.market.placeOrder({
      productId: this.productId,
      order,
      spotLeverage: undefined,
    });

    // Handle various response formats from the SDK
    const isSuccess = res?.success || res?.status === 'success' || res?.data?.status === 'success';

    if (!isSuccess) {
      const errorMsg = res?.error?.message || res?.error_response?.message || res?.message || 'placeOrder failed';
      log.warn('placeOrder failed', {
        error: errorMsg,
        fullResponse: safeStringify(res),
      });
      throw new Error(errorMsg);
    }

    log.info('Order placed successfully', {
      digest: res?.data?.digest || res?.digest,
    });

    return res?.data || res;
  }

  async _placeMarketOrder(side, amountAbsX18, reduceOnly = false) {
    if (!this.lastBbo) throw new Error('No BBO available');

    const price = computeIocPrice(side, this.lastBbo);

    const result = await this._placeOrder({
      orderExecutionType: 'ioc',
      side,
      amountAbsX18,
      price,
      reduceOnly,
    });

    return result;
  }

  async _cancelAllOrders() {
    try {
      const res = await this.nadoClient.market.cancelProductOrders({
        productId: this.productId,
        subaccountName: this.subaccount.subaccountName,
      });
      const isSuccess = res?.success || res?.status === 'success';
      if (isSuccess) {
        log.info('Cancelled all open orders', { product: this.productSymbol });
      } else {
        log.debug('Cancel orders response', { res: safeStringify(res) });
      }
    } catch (err) {
      log.debug('Cancel all orders skipped', { product: this.productSymbol, error: err.message });
    }
    this.pending.clear();
  }

  // ==================== Position Size Calculation ====================

  async _computePositionSizeForTier(tier, collateralUsd, assetPrice) {
    if (!tier.enabled) return 0n;

    const maxNotional = collateralUsd * tier.maxLeverage;
    const targetNotional = clamp(collateralUsd * tier.targetLeverage, 0, maxNotional);

    const rawSize = targetNotional / assetPrice;
    const sizeX18 = BigInt(Math.floor(rawSize * 1e18));

    let rounded = roundDownToIncrementX18(sizeX18, this.sizeIncrementX18);

    if (rounded < this.minOrderSizeX18) {
      rounded = this.minOrderSizeX18;
    }

    const maxSize = maxNotional / assetPrice;
    const maxSizeX18 = BigInt(Math.floor(maxSize * 1e18));
    if (rounded > maxSizeX18) {
      rounded = roundDownToIncrementX18(maxSizeX18, this.sizeIncrementX18);
    }

    if (rounded < this.minOrderSizeX18) return 0n;

    return rounded;
  }

  // ==================== Multi-Position Entry/Exit ====================

  async _enterPositionForTier(tier, side) {
    if (this.inFlight) {
      log.debug('Entry skipped - order in flight', { product: this.productSymbol, tier: tier.tierId });
      return false;
    }

    const state = await getSubaccountState(this.nadoClient, this.subaccount, this.productId);
    const collateralUsd = Number(state.collateralX18) / 1e18;

    if (!this.lastBbo) return false;

    const bid = Number(this.lastBbo.bid);
    const ask = Number(this.lastBbo.ask);
    const assetPrice = (bid + ask) / 2;

    if (!Number.isFinite(assetPrice) || assetPrice <= 0) return false;

    const amountAbsX18 = await this._computePositionSizeForTier(tier, collateralUsd, assetPrice);
    if (amountAbsX18 <= 0n) {
      log.warn('Entry skipped - computed size is 0', { product: this.productSymbol, tier: tier.tierId });
      return false;
    }

    this.inFlight = true;
    try {
      log.info('Entering position', {
        product: this.productSymbol,
        tier: tier.tierId,
        leverage: tier.targetLeverage + 'x',
        side,
        amount: x18ToDecimalString(amountAbsX18),
        zone: getZoneName(),
      });

      const result = await this._placeMarketOrder(side, amountAbsX18, false);

      // Update tier state
      tier.positionX18 = side === 'buy' ? amountAbsX18 : -amountAbsX18;
      tier.side = side;
      tier.entryTime = Date.now();

      const entryPrice = side === 'buy'
        ? this.lastBbo.askPriceX18
        : this.lastBbo.bidPriceX18;

      tier.entryPriceX18 = BigInt(entryPrice);
      tier.peakPriceX18 = tier.entryPriceX18;

      // Reset TP zone
      tier.tpZone = { active: false, peakProfitPct: 0, enteredAt: null };

      // Update total position
      this._updateTotalPosition();

      // Save state
      this._saveAllTierState();

      log.info('Position entered', {
        product: this.productSymbol,
        tier: tier.tierId,
        side,
        entryPrice: x18ToDecimalString(tier.entryPriceX18),
        digest: result?.digest,
      });

      return true;
    } catch (err) {
      log.error('Entry failed', { product: this.productSymbol, tier: tier.tierId, error: err.message });
      return false;
    } finally {
      this.inFlight = false;
    }
  }

  async _closePositionForTier(tier, reason) {
    if (tier.isFlat()) {
      log.debug('Close skipped - no position', { tier: tier.tierId });
      return false;
    }

    if (this.inFlight) {
      log.debug('Close skipped - order in flight', { tier: tier.tierId });
      return false;
    }

    const side = tier.isLong() ? 'sell' : 'buy';
    const amountAbsX18 = bigintAbs(tier.positionX18);

    this.inFlight = true;
    try {
      log.info('Closing position', {
        tier: tier.tierId,
        reason,
        side,
        amount: x18ToDecimalString(amountAbsX18),
      });

      const result = await this._placeMarketOrder(side, amountAbsX18, true);

      // Calculate P&L
      const exitPrice = side === 'sell'
        ? this.lastBbo.bidPriceX18
        : this.lastBbo.askPriceX18;

      const pnlPct = this._calculateProfitPctForTier(tier, BigInt(exitPrice));
      const isWin = pnlPct > 0;

      // Update stats
      if (isWin) {
        this.stats.wins++;
      } else {
        this.stats.losses++;
      }

      log.info('Position closed', {
        tier: tier.tierId,
        reason,
        pnlPct: pnlPct.toFixed(4) + '%',
        isWin,
        digest: result?.digest,
      });

      // Reset tier
      tier.reset();

      // Update total position
      this._updateTotalPosition();

      // Save state
      this._saveAllTierState();

      return true;
    } catch (err) {
      log.error('Close failed', { tier: tier.tierId, error: err.message });
      return false;
    } finally {
      this.inFlight = false;
    }
  }

  async _enterAllPositions(side) {
    log.info('Entering all positions', { side, tierCount: this.tiers.length });

    for (const tier of this.tiers) {
      if (tier.enabled && tier.isFlat()) {
        await this._enterPositionForTier(tier, side);
        await sleep(500); // Brief pause between orders
      }
    }
  }

  async _closeAllPositions(reason) {
    log.info('Closing all positions', { reason });

    for (const tier of this.tiers) {
      if (!tier.isFlat()) {
        await this._closePositionForTier(tier, reason);
        await sleep(500);
      }
    }
  }

  _updateTotalPosition() {
    this.totalPositionX18 = this.tiers.reduce((sum, tier) => sum + tier.positionX18, 0n);
  }

  _saveAllTierState() {
    this.state.tiers = this.tiers.map(t => t.toJSON());
    this.stateManager.saveBotState(this.state);
  }

  _loadAllTierState() {
    if (this.state.tiers && Array.isArray(this.state.tiers)) {
      for (const tierData of this.state.tiers) {
        const tier = this.tiers.find(t => t.tierId === tierData.tierId);
        if (tier) {
          tier.fromJSON(tierData);
        }
      }
      this._updateTotalPosition();
      log.info('Restored tier state from disk', {
        tiers: this.tiers.map(t => ({
          id: t.tierId,
          position: x18ToDecimalString(bigintAbs(t.positionX18)),
          side: t.getCurrentSide(),
        })),
      });
    }
  }

  // ==================== Profit Taking Logic (Per Tier) ====================

  _calculateProfitPctForTier(tier, currentPriceX18 = null) {
    if (tier.entryPriceX18 === 0n || tier.isFlat()) return 0;

    if (!currentPriceX18 && this.lastBbo) {
      currentPriceX18 = tier.isLong()
        ? BigInt(this.lastBbo.bidPriceX18)
        : BigInt(this.lastBbo.askPriceX18);
    }

    if (!currentPriceX18) return 0;

    const diff = currentPriceX18 - tier.entryPriceX18;
    const profitX18 = tier.isLong() ? diff : -diff;

    return Number(profitX18 * 10000n / tier.entryPriceX18) / 100;
  }

  _checkProfitTargetsForTier(tier) {
    if (tier.isFlat() || !this.lastBbo || tier.entryPriceX18 === 0n) {
      return;
    }

    const profitPct = this._calculateProfitPctForTier(tier);

    // Update peak price for trailing stop
    const currentPriceX18 = tier.isLong()
      ? BigInt(this.lastBbo.bidPriceX18)
      : BigInt(this.lastBbo.askPriceX18);

    if (tier.isLong() && currentPriceX18 > tier.peakPriceX18) {
      tier.peakPriceX18 = currentPriceX18;
    } else if (tier.isShort() && currentPriceX18 < tier.peakPriceX18) {
      tier.peakPriceX18 = currentPriceX18;
    }

    // Update peak profit
    if (profitPct > tier.tpZone.peakProfitPct) {
      tier.tpZone.peakProfitPct = profitPct;
    }

    // Check if entered TP Zone (use tier-specific target)
    if (profitPct >= tier.profitTargetPct && !tier.tpZone.active) {
      log.info('Entered TP Zone', {
        tier: tier.tierId,
        profitPct: profitPct.toFixed(4) + '%',
        target: tier.profitTargetPct + '%',
      });
      tier.tpZone.active = true;
      tier.tpZone.enteredAt = Date.now();
    }

    // Check trailing stop (use tier-specific trailing stop)
    if (tier.tpZone.active && config.enableTrailingStop) {
      const drawdownFromPeak = tier.tpZone.peakProfitPct - profitPct;

      if (drawdownFromPeak >= tier.trailingStopPct) {
        log.warn('Trailing stop triggered', {
          tier: tier.tierId,
          peakProfitPct: tier.tpZone.peakProfitPct.toFixed(4) + '%',
          currentProfitPct: profitPct.toFixed(4) + '%',
          drawdown: drawdownFromPeak.toFixed(4) + '%',
          trailingStop: tier.trailingStopPct + '%',
        });
        // Queue close and re-entry for this tier
        setImmediate(async () => {
          const closed = await this._closePositionForTier(tier, 'trailing_stop');
          if (closed) {
            // Re-enter in the same zone direction
            const currentZoneSide = getZoneSide();
            log.info('Auto re-entry after profit taking', {
              tier: tier.tierId,
              side: currentZoneSide,
            });
            await sleep(1000); // Brief pause before re-entry
            await this._enterPositionForTier(tier, currentZoneSide);
          }
        });
      }
    }
  }

  _checkAllProfitTargets() {
    for (const tier of this.tiers) {
      this._checkProfitTargetsForTier(tier);
    }
  }

  // ==================== Zone Flip Logic ====================

  async _onZoneFlip() {
    const now = nowInTimezone();
    const newSide = getZoneSide(now);
    const zoneInfo = getNextZoneFlipInfo(now);

    log.info('Zone flip triggered', {
      time: formatTime(now),
      newZone: zoneInfo.currentZone,
      newSide,
      isMarketDay: isMarketDay(now, config.skipUSHolidays),
    });

    // Skip on non-market days
    if (!isMarketDay(now, config.skipUSHolidays)) {
      const reason = getNonMarketDayReason(now);
      log.info('Skipping zone flip - non-market day', { reason });
      return;
    }

    // Process each tier
    for (const tier of this.tiers) {
      const currentSide = tier.getCurrentSide();

      // Check if we should hold profitable position
      if (!tier.isFlat() && config.holdIfProfitable) {
        const profitPct = this._calculateProfitPctForTier(tier);
        const hoursUntilFlip = hoursUntilNextZoneFlip(now);

        if (tier.tpZone.active && hoursUntilFlip < config.tpZoneHoursThreshold) {
          log.info('Skipping zone flip for tier - holding profitable position', {
            tier: tier.tierId,
            profitPct: profitPct.toFixed(4) + '%',
            hoursUntilNextFlip: hoursUntilFlip.toFixed(1),
          });
          continue;
        }
      }

      // Close if wrong side
      if (currentSide && currentSide !== newSide) {
        await this._closePositionForTier(tier, 'zone_flip');
        await sleep(500);
      }

      // Enter if flat
      if (tier.isFlat()) {
        await this._enterPositionForTier(tier, newSide);
        await sleep(500);
      }
    }

    // Update zone state
    this.state.lastZone = {
      side: newSide,
      flipTime: Date.now(),
    };
    this.stateManager.saveBotState(this.state);
  }

  // ==================== Scheduling ====================

  _setupCronSchedule() {
    const openCron = `${config.marketOpenMinute} ${config.marketOpenHour} * * 1-5`;
    const openJob = cron.schedule(
      openCron,
      () => {
        log.info('Cron: Market open zone flip');
        this._onZoneFlip().catch(err => {
          log.error('Zone flip error', { error: err.message });
        });
      },
      { timezone: config.timezone }
    );

    const closeCron = `${config.marketCloseMinute} ${config.marketCloseHour} * * 1-5`;
    const closeJob = cron.schedule(
      closeCron,
      () => {
        log.info('Cron: Market close zone flip');
        this._onZoneFlip().catch(err => {
          log.error('Zone flip error', { error: err.message });
        });
      },
      { timezone: config.timezone }
    );

    this._scheduledJobs.push(openJob, closeJob);

    log.info('Cron schedules configured', {
      marketOpen: openCron,
      marketClose: closeCron,
      timezone: config.timezone,
    });
  }

  _stopCronSchedule() {
    for (const job of this._scheduledJobs) {
      job.stop();
    }
    this._scheduledJobs = [];
  }

  // ==================== Fill Handling ====================

  _onFill(fill) {
    const digest = fill.order_digest;
    const filledAbsX18 = BigInt(fill.filled_qty || '0');
    const remainingAbsX18 = BigInt(fill.remaining_qty || '0');
    const isBuy = !!fill.is_bid;

    // Update pending orders
    if (digest && this.pending.has(digest)) {
      const p = this.pending.get(digest);
      p.remainingAbsX18 = remainingAbsX18;
      if (remainingAbsX18 === 0n && typeof p.resolve === 'function') {
        p.resolve({ remainingAbsX18 });
        p.resolve = null;
      }
    }

    // Stats
    const priceX18 = BigInt(fill.price || '0');
    if (filledAbsX18 > 0n && priceX18 > 0n) {
      const notionalX18 = (filledAbsX18 * priceX18) / ONE_E18;
      const notionalUsd = Number(notionalX18) / 1e18;
      this.stats.fills++;
      this.stats.notionalUsd += Math.abs(notionalUsd);
      this.stats.baseQty += Number(filledAbsX18) / 1e18;
    }

    log.info('Fill', {
      productId: fill.product_id,
      digest,
      isBuy,
      filledQty: fill.filled_qty,
      remainingQty: fill.remaining_qty,
      isTaker: fill.is_taker,
    });
  }

  // ==================== Safety Checks ====================

  async _checkBalanceFloor() {
    const now = Date.now();
    if (now - this._lastBalanceCheckMs < 30000) return true;
    this._lastBalanceCheckMs = now;

    try {
      const state = await getSubaccountState(this.nadoClient, this.subaccount, this.productId);
      const balanceUsd = Number(state.collateralX18) / 1e18;

      if (balanceUsd < config.balanceFloorUsd) {
        log.error('BALANCE FLOOR BREACHED', {
          currentBalance: balanceUsd.toFixed(2),
          balanceFloor: config.balanceFloorUsd,
        });

        await this._cancelAllOrders();
        await this._emergencyFlatten();
        this._tradingHalted = true;

        log.error('EMERGENCY SHUTDOWN COMPLETE - Bot halted');
        return false;
      }

      log.debug('Balance check passed', {
        balance: balanceUsd.toFixed(2),
        floor: config.balanceFloorUsd,
      });
      return true;
    } catch (err) {
      log.warn('Balance check failed', { error: err.message });
      return true;
    }
  }

  async _periodicReconcile() {
    const now = Date.now();
    if (now - this._lastReconcileMs < 15000) return true;
    this._lastReconcileMs = now;

    try {
      const state = await getSubaccountState(this.nadoClient, this.subaccount, this.productId);
      const onChainPosition = state.positionAmountX18;

      const diff = bigintAbs(onChainPosition - this.totalPositionX18);
      const threshold = 1_000_000_000_000n;

      if (diff > threshold) {
        this._reconcileMismatchCount++;
        log.warn('POSITION MISMATCH', {
          onChain: onChainPosition.toString(),
          localTotal: this.totalPositionX18.toString(),
          mismatchCount: this._reconcileMismatchCount,
        });

        if (this._reconcileMismatchCount >= 2) {
          log.error('REPEATED MISMATCH - Emergency shutdown');
          await this._cancelAllOrders();
          await this._emergencyFlatten();
          this._tradingHalted = true;
          return false;
        }
      } else {
        this._reconcileMismatchCount = 0;
      }

      return true;
    } catch (err) {
      log.warn('Reconciliation failed', { error: err.message });
      return true;
    }
  }

  async _emergencyFlatten() {
    const state = await getSubaccountState(this.nadoClient, this.subaccount, this.productId);
    const positionX18 = state.positionAmountX18;

    if (positionX18 === 0n) {
      log.info('No position to flatten');
      return;
    }

    const side = positionX18 > 0n ? 'sell' : 'buy';
    const amountAbsX18 = bigintAbs(positionX18);

    if (!this.lastBbo) {
      log.error('Cannot flatten - no BBO available');
      return;
    }

    log.warn('EMERGENCY FLATTEN', {
      side,
      amount: x18ToDecimalString(amountAbsX18),
    });

    try {
      await this._placeMarketOrder(side, amountAbsX18, true);

      // Reset all tiers
      for (const tier of this.tiers) {
        tier.reset();
      }
      this._updateTotalPosition();
      this._saveAllTierState();

      log.info('Emergency flatten order sent');
    } catch (err) {
      log.error('Emergency flatten failed', { error: err.message });
    }
  }

  async _startupReconciliation() {
    log.info('STARTUP RECONCILIATION');

    try {
      await this._cancelAllOrders();

      const state = await getSubaccountState(this.nadoClient, this.subaccount, this.productId);
      const onChainPosition = state.positionAmountX18;

      // Load tier state from disk
      this._loadAllTierState();

      this.pending.clear();
      this.inFlight = false;
      this._reconcileMismatchCount = 0;

      log.info('STARTUP RECONCILIATION COMPLETE', {
        onChainPosition: onChainPosition.toString(),
        localTotalPosition: this.totalPositionX18.toString(),
        activeTiers: this.tiers.filter(t => !t.isFlat()).length,
      });

      return true;
    } catch (err) {
      log.error('Startup reconciliation failed', { error: err.message });
      return false;
    }
  }

  // ==================== Main Loop ====================

  _logStatus() {
    const zoneInfo = getNextZoneFlipInfo();

    const tierStatus = this.tiers.map(t => ({
      tier: t.tierId,
      pos: t.isFlat() ? 'FLAT' : (t.isLong() ? 'LONG' : 'SHORT'),
      size: x18ToDecimalString(bigintAbs(t.positionX18)),
      pnl: this._calculateProfitPctForTier(t).toFixed(2) + '%',
      tp: t.tpZone.active,
    }));

    log.info('Status', {
      product: this.productSymbol,
      zone: zoneInfo.currentZone,
      totalPosition: x18ToDecimalString(bigintAbs(this.totalPositionX18)),
      tiers: tierStatus,
      nextFlip: zoneInfo.nextFlipTimeFormatted,
      minutesUntilFlip: zoneInfo.minutesUntilFlip,
    });
  }

  /**
   * Check for any flat tiers and re-enter positions in the current zone direction.
   * This ensures positions are restored after profit taking or manual closure.
   * Rate-limited to avoid spamming entries.
   */
  async _checkAndEnterFlatTiers() {
    // Rate limit: only check every 30 seconds
    const now = Date.now();
    if (now - (this._lastFlatCheckMs || 0) < 30000) return;
    this._lastFlatCheckMs = now;

    const desiredSide = getZoneSide();
    const flatTiers = this.tiers.filter(t => t.enabled && t.isFlat());

    if (flatTiers.length === 0) return;

    // Check if we're on a market day
    const nowTime = nowInTimezone();
    if (!isMarketDay(nowTime, config.skipUSHolidays)) {
      return; // Don't enter on non-market days
    }

    log.info('Found flat tiers - attempting re-entry', {
      product: this.productSymbol,
      flatTierCount: flatTiers.length,
      tiers: flatTiers.map(t => t.tierId),
      desiredSide,
    });

    for (const tier of flatTiers) {
      await this._enterPositionForTier(tier, desiredSide);
      await sleep(1000); // Stagger entries
    }
  }

  async _alignToCurrentZone() {
    const desiredSide = getZoneSide();

    log.info('Aligning all tiers to current zone', { desiredSide });

    for (const tier of this.tiers) {
      const currentSide = tier.getCurrentSide();

      if (currentSide && currentSide !== desiredSide) {
        await this._closePositionForTier(tier, 'zone_alignment');
        await sleep(500);
      }

      if (tier.isFlat()) {
        await this._enterPositionForTier(tier, desiredSide);
        await sleep(500);
      }
    }
  }

  async gracefulShutdown() {
    log.warn('GRACEFUL SHUTDOWN - Preserving positions');
    this._stopCronSchedule();

    try {
      // Cancel any pending orders but KEEP positions open
      await this._cancelAllOrders();

      // Save current state to disk for restart recovery
      this._saveAllTierState();

      const openPositions = this.tiers.filter(t => !t.isFlat());
      log.info('GRACEFUL SHUTDOWN COMPLETE', {
        positionsPreserved: openPositions.length,
        tiers: openPositions.map(t => ({
          tier: t.tierId,
          side: t.getCurrentSide(),
          size: x18ToDecimalString(bigintAbs(t.positionX18)),
        })),
      });
    } catch (err) {
      log.error('Shutdown error', { error: err.message });
    }
  }

  async runForever() {
    log.info('TimeZone Strategy starting', {
      product: this.productSymbol,
      productId: this.productId,
      timezone: config.timezone,
      marketOpen: `${config.marketOpenHour}:${String(config.marketOpenMinute).padStart(2, '0')}`,
      marketClose: `${config.marketCloseHour}:${String(config.marketCloseMinute).padStart(2, '0')}`,
      profitTarget: config.profitTargetPct + '%',
      trailingStop: config.trailingStopPct + '%',
      multiPosition: config.enableMultiPosition,
      tierCount: this.tiers.length,
      dryRun: config.dryRun,
    });

    if (config.dryRun) {
      log.warn('DRY_RUN MODE ENABLED - No trades will be executed');
    }

    // Startup
    if (!config.dryRun) {
      const startupOk = await this._startupReconciliation();
      if (!startupOk) {
        log.error('Startup failed - halting');
        this._tradingHalted = true;
      }
    }

    // Setup cron schedules
    this._setupCronSchedule();

    // Initial alignment (if not dry run)
    if (!config.dryRun && !this._tradingHalted) {
      await this._alignToCurrentZone();
    }

    // Log initial status
    this._logStatus();

    // Main monitoring loop
    let statusLogCounter = 0;
    while (true) {
      try {
        if (!this.lastBbo) {
          await sleep(250);
          continue;
        }

        if (config.dryRun) {
          statusLogCounter++;
          if (statusLogCounter % 25 === 0) {
            this._logStatus();
          }
          await sleep(config.loopDelayMs);
          continue;
        }

        if (this._tradingHalted) {
          log.warn('Trading halted - restart required');
          await sleep(30000);
          continue;
        }

        // Safety checks
        const balanceOk = await this._checkBalanceFloor();
        if (!balanceOk) continue;

        const reconcileOk = await this._periodicReconcile();
        if (!reconcileOk) continue;

        // Check for flat tiers and re-enter if needed
        await this._checkAndEnterFlatTiers();

        // Log status periodically
        statusLogCounter++;
        if (statusLogCounter % 150 === 0) {
          this._logStatus();
        }

      } catch (err) {
        log.warn('Loop error', { error: err.message });
        await sleep(1000);
      }

      await sleep(config.loopDelayMs);
    }
  }
}
