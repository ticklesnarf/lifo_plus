// src/strategy.js
import { packOrderAppendix } from '@nadohq/client';

import { config } from './config.js';
import { log, safeStringify } from './logger.js';
import { nowSeconds, sleep, bigintAbs, roundDownToIncrementX18, roundUpToIncrementX18, x18ToDecimalString, clamp } from './utils.js';
import { getSubaccountState } from './nadoClient.js';

const ONE_E18 = 10n ** 18n;

function sideToSignedAmountX18(side, amountAbsX18) {
  if (side === 'buy') return amountAbsX18;
  if (side === 'sell') return -amountAbsX18;
  throw new Error(`Invalid side: ${side}`);
}

function computeIocPriceX18(side, bbo) {
  const bidX18 = BigInt(bbo.bidPriceX18 || '0');
  const askX18 = BigInt(bbo.askPriceX18 || '0');

  if (bidX18 <= 0n || askX18 <= 0n) {
    throw new Error('Invalid BBO for IOC price computation');
  }

  const slippageBps = BigInt(config.iocSlippageBps);
  const bpsDen = 10_000n;

  if (side === 'buy') {
    const raw = (askX18 * (bpsDen + slippageBps)) / bpsDen;
    if (config.priceIncrementX18 > 0n) {
      return roundUpToIncrementX18(raw, config.priceIncrementX18);
    }
    return raw;
  } else {
    const raw = (bidX18 * (bpsDen - slippageBps)) / bpsDen;
    if (config.priceIncrementX18 > 0n) {
      return roundDownToIncrementX18(raw, config.priceIncrementX18);
    }
    return raw;
  }
}

function computeIocPrice(side, bbo) {
  const iocPriceX18 = computeIocPriceX18(side, bbo);
  return x18ToDecimalString(iocPriceX18);
}

export class StrategyEngine {
  constructor({ nadoClient, subaccount, subscriptions }) {
    this.nadoClient = nadoClient;
    this.subaccount = subaccount;
    this.subscriptions = subscriptions;

    this.lastBbo = null;

    this.positionX18 = 0n;
    this.lastPositionChangeMs = Date.now();

    this.inFlight = false;

    // digest -> { originalAbsX18, remainingAbsX18, resolve }
    this.pending = new Map();

    // stats
    this.stats = {
      startTime: Date.now(),
      fills: 0,
      notionalUsd: 0,
      baseQty: 0,
    };

    this.nextEntrySide = 'buy';
    this._tradingHalted = false;
    this._lastBalanceCheckMs = 0;
    this._lastReconcileMs = 0;
    this._reconcileMismatchCount = 0;

    this._wireEvents();
  }

  _wireEvents() {
    this.subscriptions.on('bbo', (bbo) => {
      this.lastBbo = bbo;
    });

    this.subscriptions.on('fill', (fill) => {
      try {
        this._onFill(fill);
      } catch (err) {
        log.warn('Error handling fill', { error: String(err?.message || err) });
      }
    });
  }

  _logDryRunStatus() {
    if (!this.lastBbo) return;
    
    const bid = this.lastBbo.bid;
    const ask = this.lastBbo.ask;
    const spread = ((Number(ask) - Number(bid)) / Number(bid) * 100).toFixed(4);
    
    log.info('DRY_RUN observation', {
      productId: config.productId,
      bid,
      ask,
      spreadPct: spread + '%',
      minOrderSize: (Number(config.minOrderSizeX18) / 1e18).toFixed(8) + ' BTC',
      targetLeverage: config.targetLeverage + 'x',
    });
  }

  async _cancelAllOrders() {
    try {
      const res = await this.nadoClient.market.cancelProductOrders({
        productId: config.productId,
        subaccountName: this.subaccount.subaccountName,
      });
      if (res?.success) {
        log.info('Cancelled all open orders for product', { productId: config.productId });
      } else {
        log.warn('Cancel all orders response', { error: res?.error?.message || res?.error_response?.message });
      }
    } catch (err) {
      log.warn('Cancel all orders failed', { error: err.message });
    }
    this.pending.clear();
  }

  async _emergencyFlatten() {
    const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
    const positionX18 = state.positionAmountX18;

    if (positionX18 === 0n) {
      log.info('No position to flatten');
      return;
    }

    const side = positionX18 > 0n ? 'sell' : 'buy';
    const amountAbsX18 = bigintAbs(positionX18);

    if (!this.lastBbo) {
      log.error('Cannot flatten - no BBO available');
      return;
    }

    const iocPrice = computeIocPrice(side, this.lastBbo);

    log.warn('EMERGENCY FLATTEN - Closing position with IOC', {
      side,
      amountAbsX18: amountAbsX18.toString(),
      iocPrice,
    });

    try {
      await this._placeOrder({
        orderExecutionType: 'ioc',
        side,
        amountAbsX18,
        price: iocPrice,
        reduceOnly: true,
      });
      log.info('Emergency flatten order sent');
    } catch (err) {
      log.error('Emergency flatten failed', { error: err.message });
    }
  }

  async _checkBalanceFloor() {
    const now = Date.now();
    if (now - this._lastBalanceCheckMs < 30000) return true;
    this._lastBalanceCheckMs = now;

    try {
      const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
      const balanceUsd = Number(state.collateralX18) / 1e18;

      if (balanceUsd < config.balanceFloorUsd) {
        log.error('BALANCE FLOOR BREACHED - Initiating emergency shutdown', {
          currentBalance: balanceUsd.toFixed(2),
          balanceFloor: config.balanceFloorUsd,
        });

        log.warn('Step 1/3: Cancelling all open orders...');
        await this._cancelAllOrders();

        log.warn('Step 2/3: Flattening position...');
        await this._emergencyFlatten();

        log.warn('Step 3/3: Halting trading');
        this._tradingHalted = true;

        log.error('EMERGENCY SHUTDOWN COMPLETE - Bot halted. Restart after recalibration.');
        return false;
      }

      log.debug('Balance check passed', { balance: balanceUsd.toFixed(2), floor: config.balanceFloorUsd });
      return true;
    } catch (err) {
      log.warn('Balance check failed', { error: err.message });
      return true;
    }
  }

  async _startupReconciliation() {
    log.info('STARTUP RECONCILIATION - Ensuring clean state before trading');

    try {
      log.info('Step 1/3: Cancelling any existing open orders...');
      await this._cancelAllOrders();

      log.info('Step 2/3: Checking for existing positions...');
      const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
      const onChainPosition = state.positionAmountX18;

      if (onChainPosition !== 0n) {
        log.warn('Found existing position on startup - flattening to start clean', {
          positionX18: onChainPosition.toString(),
        });
        await this._emergencyFlatten();
      } else {
        log.info('No existing position found - starting clean');
      }

      log.info('Step 3/3: Resetting local state trackers');
      this.positionX18 = 0n;
      this.lastPositionChangeMs = Date.now();
      this.pending.clear();
      this.inFlight = false;
      this._reconcileMismatchCount = 0;

      log.info('STARTUP RECONCILIATION COMPLETE - Ready for trading');
      return true;
    } catch (err) {
      log.error('Startup reconciliation failed', { error: err.message });
      return false;
    }
  }

  async _periodicReconcile() {
    const now = Date.now();
    const reconcileIntervalMs = 15000;
    if (now - this._lastReconcileMs < reconcileIntervalMs) return true;
    this._lastReconcileMs = now;

    try {
      const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
      const onChainPosition = state.positionAmountX18;
      const localPosition = this.positionX18;

      const diff = bigintAbs(onChainPosition - localPosition);
      const threshold = 1_000_000_000_000n;

      if (diff > threshold) {
        this._reconcileMismatchCount++;
        log.warn('POSITION MISMATCH DETECTED', {
          onChain: onChainPosition.toString(),
          local: localPosition.toString(),
          diff: diff.toString(),
          mismatchCount: this._reconcileMismatchCount,
        });

        if (this._reconcileMismatchCount >= 2) {
          log.error('REPEATED MISMATCH - Initiating emergency shutdown');

          await this._cancelAllOrders();
          await this._emergencyFlatten();

          this._tradingHalted = true;
          log.error('RECONCILIATION HALT - Manual restart required after investigation');
          return false;
        }

        log.info('Syncing local position to on-chain state');
        this.positionX18 = onChainPosition;
        this.lastPositionChangeMs = Date.now();
      } else {
        if (this._reconcileMismatchCount > 0) {
          log.info('Position reconciled - resetting mismatch counter');
        }
        this._reconcileMismatchCount = 0;
      }

      log.debug('Reconciliation check passed', {
        position: onChainPosition.toString(),
        localMatch: diff <= threshold,
      });
      return true;
    } catch (err) {
      log.warn('Reconciliation check failed', { error: err.message });
      return true;
    }
  }

  _onFill(fill) {
    // Fill event fields (per docs): order_digest, is_bid, filled_qty, remaining_qty, price, is_taker, etc.
    const digest = fill.order_digest;
    const filledAbsX18 = BigInt(fill.filled_qty || '0');
    const remainingAbsX18 = BigInt(fill.remaining_qty || '0');
    const isBuy = !!fill.is_bid;

    // Update position
    if (filledAbsX18 > 0n) {
      const delta = isBuy ? filledAbsX18 : -filledAbsX18;
      this.positionX18 += delta;
      this.lastPositionChangeMs = Date.now();
    }

    // Update pending order tracker
    if (digest && this.pending.has(digest)) {
      const p = this.pending.get(digest);
      p.remainingAbsX18 = remainingAbsX18;
      if (remainingAbsX18 === 0n && typeof p.resolve === 'function') {
        p.resolve({ remainingAbsX18 });
        p.resolve = null;
      }
    }

    // Stats: notional = filled_qty * price / 1e18 (price is x18 in events)
    const priceX18 = BigInt(fill.price || '0');
    if (filledAbsX18 > 0n && priceX18 > 0n) {
      const notionalX18 = (filledAbsX18 * priceX18) / ONE_E18;
      const notionalUsd = Number(notionalX18) / 1e18;
      this.stats.fills += 1;
      this.stats.notionalUsd += Math.abs(notionalUsd);
      this.stats.baseQty += Number(filledAbsX18) / 1e18;
    }

    log.info('Fill', {
      productId: fill.product_id,
      digest,
      isBuy,
      filledQty: fill.filled_qty,
      remainingQty: fill.remaining_qty,
      isTaker: fill.is_taker,
    });
  }

  async _placeOrder({ orderExecutionType, side, amountAbsX18, price, reduceOnly }) {
    if (config.dryRun) {
      log.warn('DRY_RUN: Order blocked', { orderExecutionType, side, amountAbsX18: amountAbsX18.toString(), price, reduceOnly });
      throw new Error('DRY_RUN mode - trading disabled');
    }

    const appendix = packOrderAppendix({ orderExecutionType, reduceOnly });

    const orderAmount = sideToSignedAmountX18(side, amountAbsX18);

    const order = {
      subaccountOwner: this.subaccount.subaccountOwner,
      subaccountName: this.subaccount.subaccountName,
      expiration: nowSeconds() + 60,
      appendix,
      price, // SDK expects a human price (not x18)
      amount: orderAmount,
    };

    const res = await this.nadoClient.market.placeOrder({
      productId: config.productId,
      order,
      spotLeverage: undefined,
    });

    if (!res?.success) {
      const errorMsg = res?.error?.message || res?.error_response?.message || 'placeOrder failed';
      log.warn('placeOrder failed', { 
        error: errorMsg, 
        fullResponse: safeStringify(res),
        orderDetails: { side, amountAbsX18: amountAbsX18.toString(), price, reduceOnly }
      });
      throw new Error(errorMsg);
    }

    return res.data; // should include digest
  }

  async _cancelOrderDigest(digest) {
    try {
      const res = await this.nadoClient.market.cancelOrders({
        digests: [digest],
        productIds: [config.productId],
        subaccountName: this.subaccount.subaccountName,
      });
      if (!res?.success) {
        log.warn('Cancel order failed', { digest, error: res?.error?.message || res?.error_response?.message });
      } else {
        log.debug('Cancel order result', res.data);
      }
    } catch (err) {
      log.warn('Cancel order threw', { digest, error: String(err?.message || err) });
    }
  }

  _waitForFillOrTimeout(digest, originalAbsX18, timeoutMs) {
    return new Promise((resolve) => {
      const entry = {
        originalAbsX18,
        remainingAbsX18: originalAbsX18,
        resolve: null,
      };

      const timer = setTimeout(() => {
        // timeout: return best known remaining
        const e = this.pending.get(digest);
        const remainingAbsX18 = e?.remainingAbsX18 ?? originalAbsX18;
        // cleanup
        this.pending.delete(digest);
        resolve({ remainingAbsX18 });
      }, timeoutMs);

      entry.resolve = ({ remainingAbsX18 }) => {
        clearTimeout(timer);
        this.pending.delete(digest);
        resolve({ remainingAbsX18 });
      };

      this.pending.set(digest, entry);
    });
  }

  async executeMakerThenFallback({ side, amountAbsX18, reduceOnly, allowIocFallback }) {
    if (!this.lastBbo) throw new Error('No best bid/offer yet');

    // Maker price: place 1 tick inside top-of-book to avoid crossing during latency.
    // For buys: bid - 1, for sells: ask + 1
    const bid = Number(this.lastBbo.bid);
    const ask = Number(this.lastBbo.ask);
    const makerPrice = side === 'buy' 
      ? String(Math.floor(bid - 1))  // 1 tick below bid for buys
      : String(Math.ceil(ask + 1));  // 1 tick above ask for sells

    log.info('Placing maker order', {
      side,
      reduceOnly,
      amountAbsX18: amountAbsX18.toString(),
      makerPrice,
    });

    const placeRes = await this._placeOrder({
      orderExecutionType: 'post_only',
      side,
      amountAbsX18,
      price: makerPrice,
      reduceOnly,
    });

    const digest = placeRes.digest;
    if (!digest) {
      throw new Error('No digest returned from placeOrder');
    }

    // Wait for fill
    const { remainingAbsX18 } = await this._waitForFillOrTimeout(
      digest,
      amountAbsX18,
      config.makerWaitMs
    );

    if (remainingAbsX18 === 0n) {
      log.info('Maker order fully filled', { digest });
      return { status: 'filled', digest };
    }

    log.info('Maker not fully filled; cancelling', {
      digest,
      remainingAbsX18: remainingAbsX18.toString(),
    });

    await this._cancelOrderDigest(digest);

    if (!allowIocFallback) {
      log.info('IOC fallback disabled; stopping after cancel', { digest });
      return { status: 'cancelled_unfilled', digest, remainingAbsX18 };
    }

    // IOC fallback for remaining qty
    const iocPrice = computeIocPrice(side, this.lastBbo);

    log.info('Placing IOC fallback', {
      side,
      reduceOnly,
      remainingAbsX18: remainingAbsX18.toString(),
      iocPrice,
    });

    const iocRes = await this._placeOrder({
      orderExecutionType: 'ioc',
      side,
      amountAbsX18: remainingAbsX18,
      price: iocPrice,
      reduceOnly,
    });

    return { status: 'ioc_sent', makerDigest: digest, iocDigest: iocRes.digest };
  }

  async _computeEntryAmountX18() {
    // Use collateral*targetLeverage (capped by maxLeverage) unless TRADE_USD_NOTIONAL is explicitly set.
    const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
    const collateralUsd = Number(state.collateralX18) / 1e18;

    if (!this.lastBbo) return 0n;
    const bid = Number(this.lastBbo.bid);
    const ask = Number(this.lastBbo.ask);
    const mid = (bid + ask) / 2;

    if (!Number.isFinite(mid) || mid <= 0) return 0n;

    const maxNotional = collateralUsd * config.maxLeverage;
    const targetNotional = config.tradeUsdNotional != null
      ? clamp(config.tradeUsdNotional, 0, maxNotional)
      : clamp(collateralUsd * config.targetLeverage, 0, maxNotional);

    const rawSize = targetNotional / mid; // base units (e.g., BTC)
    const sizeX18 = BigInt(Math.floor(rawSize * 1e18));

    let rounded = roundDownToIncrementX18(sizeX18, config.sizeIncrementX18);

    if (rounded < config.minOrderSizeX18) {
      // If below minimum, either bump to minimum (if affordable) or skip.
      rounded = config.minOrderSizeX18;
    }

    // Hard cap: do not exceed maxNotional in size terms.
    const maxSize = maxNotional / mid;
    const maxSizeX18 = BigInt(Math.floor(maxSize * 1e18));
    if (rounded > maxSizeX18) rounded = roundDownToIncrementX18(maxSizeX18, config.sizeIncrementX18);

    if (rounded < config.minOrderSizeX18) return 0n;
    return rounded;
  }

  _shouldForceClose() {
    if (this.positionX18 === 0n) return false;
    const heldMs = Date.now() - this.lastPositionChangeMs;
    return heldMs > config.maxHoldMs;
  }

  async gracefulShutdown() {
    if (config.dryRun) {
      log.info('DRY_RUN: Shutdown cleanup skipped');
      return;
    }

    log.warn('GRACEFUL SHUTDOWN - Cleaning up risk exposure');

    try {
      log.info('Step 1/2: Cancelling all open orders...');
      await this._cancelAllOrders();

      log.info('Step 2/2: Checking for open position...');
      const state = await getSubaccountState(this.nadoClient, this.subaccount, config.productId);
      const positionX18 = state.positionAmountX18;

      if (positionX18 !== 0n) {
        log.warn('Open position found - flattening before exit', {
          positionX18: positionX18.toString(),
        });
        await this._emergencyFlatten();
        log.info('Position flatten order sent');
      } else {
        log.info('No open position - clean exit');
      }

      log.info('GRACEFUL SHUTDOWN COMPLETE');
    } catch (err) {
      log.error('Graceful shutdown error', { error: err.message });
    }
  }

  async runForever() {
    log.info('Strategy engine starting', { dryRun: config.dryRun });

    if (config.dryRun) {
      log.warn('DRY_RUN MODE ENABLED - No trades will be executed');
    } else {
      log.info('Running startup reconciliation...');
      const startupOk = await this._startupReconciliation();
      if (!startupOk) {
        log.error('Startup reconciliation failed - halting');
        this._tradingHalted = true;
      }
    }

    while (true) {
      try {
        if (!this.lastBbo) {
          await sleep(250);
          continue;
        }

        if (config.dryRun) {
          this._logDryRunStatus();
          await sleep(5000);
          continue;
        }

        if (this._tradingHalted) {
          log.warn('Trading halted. Restart bot after investigation.');
          await sleep(30000);
          continue;
        }

        const balanceOk = await this._checkBalanceFloor();
        if (!balanceOk) {
          continue;
        }

        const reconcileOk = await this._periodicReconcile();
        if (!reconcileOk) {
          continue;
        }

        if (this.inFlight) {
          await sleep(config.loopDelayMs);
          continue;
        }

        // Failsafe: force close if holding too long
        if (this._shouldForceClose()) {
          log.warn('MAX_HOLD_MS exceeded; forcing close', { positionX18: this.positionX18.toString() });
          await this._closePosition({ forceIoc: true });
          await sleep(config.loopDelayMs);
          continue;
        }

        if (this.positionX18 === 0n) {
          await this._enterOnce();
        } else {
          await this._closePosition({ forceIoc: false });
        }

        // Periodic stats
        const runtimeSec = (Date.now() - this.stats.startTime) / 1000;
        if (runtimeSec > 0 && this.stats.fills % 10 === 0 && this.stats.fills !== 0) {
          log.info('Stats', {
            fills: this.stats.fills,
            notionalUsd: this.stats.notionalUsd.toFixed(2),
            runtimeSec: Math.round(runtimeSec),
          });
        }

      } catch (err) {
        log.warn('Strategy loop error', { error: String(err?.message || err) });
        // brief backoff on errors
        await sleep(750);
      }

      await sleep(config.loopDelayMs);
    }
  }

  async _enterOnce() {
    const amountAbsX18 = await this._computeEntryAmountX18();
    if (amountAbsX18 <= 0n) {
      log.info('Entry skipped: size=0');
      return;
    }

    const side = this.nextEntrySide;

    this.inFlight = true;
    try {
      await this.executeMakerThenFallback({
        side,
        amountAbsX18,
        reduceOnly: false,
        allowIocFallback: config.fallbackIocOnEntry,
      });

      // After attempting entry, we do not toggle side until we complete a full round-trip.
      // Toggling happens when we return to flat after a close.
    } finally {
      this.inFlight = false;
    }
  }

  async _closePosition({ forceIoc }) {
    const pos = this.positionX18;
    if (pos === 0n) return;

    const side = pos > 0n ? 'sell' : 'buy';
    const amountAbsX18 = bigintAbs(pos);

    this.inFlight = true;
    try {
      await this.executeMakerThenFallback({
        side,
        amountAbsX18,
        reduceOnly: true,
        allowIocFallback: forceIoc ? true : config.fallbackIocOnExit,
      });

      // If we have returned to flat, toggle next entry side to alternate long/short.
      if (this.positionX18 === 0n) {
        this.nextEntrySide = this.nextEntrySide === 'buy' ? 'sell' : 'buy';
        log.info('Flat after close; toggling next entry side', { nextEntrySide: this.nextEntrySide });
      }
    } finally {
      this.inFlight = false;
    }
  }
}
