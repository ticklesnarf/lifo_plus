// src/index.js
import cron from 'node-cron';
import { config } from './config.js';
import { log } from './logger.js';
import { createClients } from './nadoClient.js';
import { NadoSubscriptions } from './nadoSubscriptions.js';
import { TimeZoneStrategy } from './timeZoneStrategy.js';
import { adaptiveLearning } from './adaptiveLearning.js';
import { getProductSymbol } from './products.js';

async function main() {
  log.info('='.repeat(60));
  log.info('Bitcoin9to5 Nado Trading Bot - Multi-Product Edition');
  log.info('Strategy: SHORT during US market hours, LONG otherwise');
  log.info('='.repeat(60));

  const { nadoClient, walletClient, account, subaccount, chainId } = createClients();

  // Log products being traded
  const productSymbols = config.productIds.map(id => `${getProductSymbol(id)} (${id})`);
  log.info('Trading products', { products: productSymbols });

  const subscriptions = new NadoSubscriptions({
    productId: config.productId,
    productIds: config.productIds,
    address: account.address,
    subaccountName: config.subaccountName,
    walletClient,
    chainId,
  });

  await subscriptions.start();

  // Create a strategy instance for each product
  const strategies = [];
  for (const productId of config.productIds) {
    const strategy = new TimeZoneStrategy({
      nadoClient,
      subaccount,
      subscriptions,
      productId,
    });
    strategies.push(strategy);
    log.info('Strategy initialized', { productId, symbol: getProductSymbol(productId) });
  }

  // Setup daily adaptive learning optimization (midnight ET)
  if (config.enableAdaptiveLearning) {
    cron.schedule('0 0 * * *', () => {
      log.info('Cron: Running daily adaptive learning');
      adaptiveLearning.runDailyOptimization().catch(err => {
        log.error('Adaptive learning cron error', { error: err.message });
      });
    }, { timezone: config.timezone });

    log.info('Adaptive learning enabled', {
      lookbackDays: config.learningLookbackDays,
      scheduledAt: 'midnight ' + config.timezone,
    });
  }

  // Graceful shutdown with risk cleanup
  let isShuttingDown = false;
  const shutdown = async () => {
    if (isShuttingDown) return;
    isShuttingDown = true;

    log.warn('Shutdown signal received...');

    try {
      // Shutdown all strategies
      for (const strategy of strategies) {
        await strategy.gracefulShutdown();
      }
    } catch (err) {
      log.error('Shutdown cleanup error', { error: String(err?.message || err) });
    }

    try {
      subscriptions.stop();
    } catch {
      // ignore
    }

    log.info('Exiting');
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  process.on('unhandledRejection', (reason) => {
    log.error('Unhandled promise rejection', { reason: String(reason) });
  });
  process.on('uncaughtException', (err) => {
    log.error('Uncaught exception', { error: String(err?.message || err) });
  });

  // Run all strategies concurrently
  await Promise.all(strategies.map(s => s.runForever()));
}

main().catch((err) => {
  log.error('Fatal error', { error: String(err?.message || err) });
  process.exit(1);
});
