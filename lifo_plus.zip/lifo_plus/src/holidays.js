// src/holidays.js
import { DateTime } from 'luxon';

/**
 * US Market Holiday Detection
 * NYSE/NASDAQ holiday calendar for 2024-2026
 */

// US market holidays (dates when NYSE/NASDAQ are closed)
const US_HOLIDAYS = new Set([
  // 2024
  '2024-01-01', // New Year's Day
  '2024-01-15', // MLK Day
  '2024-02-19', // Presidents Day
  '2024-03-29', // Good Friday
  '2024-05-27', // Memorial Day
  '2024-06-19', // Juneteenth
  '2024-07-04', // Independence Day
  '2024-09-02', // Labor Day
  '2024-11-28', // Thanksgiving
  '2024-12-25', // Christmas

  // 2025
  '2025-01-01', // New Year's Day
  '2025-01-20', // MLK Day
  '2025-02-17', // Presidents Day
  '2025-04-18', // Good Friday
  '2025-05-26', // Memorial Day
  '2025-06-19', // Juneteenth
  '2025-07-04', // Independence Day
  '2025-09-01', // Labor Day
  '2025-11-27', // Thanksgiving
  '2025-12-25', // Christmas

  // 2026
  '2026-01-01', // New Year's Day
  '2026-01-19', // MLK Day
  '2026-02-16', // Presidents Day
  '2026-04-03', // Good Friday
  '2026-05-25', // Memorial Day
  '2026-06-19', // Juneteenth
  '2026-07-03', // Independence Day (observed)
  '2026-09-07', // Labor Day
  '2026-11-26', // Thanksgiving
  '2026-12-25', // Christmas
]);

// Default timezone
let _timezone = 'America/New_York';

/**
 * Set the timezone for holiday checking
 */
export function setHolidayTimezone(tz) {
  _timezone = tz;
}

/**
 * Get current date in the configured timezone
 */
function getCurrentDate() {
  return DateTime.now().setZone(_timezone);
}

/**
 * Check if a given date is a US market holiday
 */
export function isUSHoliday(date = getCurrentDate()) {
  const dateStr = date.toFormat('yyyy-MM-dd');
  return US_HOLIDAYS.has(dateStr);
}

/**
 * Check if a given date is a weekend (Saturday or Sunday)
 */
export function isWeekend(date = getCurrentDate()) {
  const dow = date.weekday; // 1=Monday, 7=Sunday (ISO weekday)
  return dow === 6 || dow === 7;
}

/**
 * Check if a given date is a trading day (weekday and not a holiday)
 */
export function isMarketDay(date = getCurrentDate(), skipHolidays = true) {
  if (isWeekend(date)) {
    return false;
  }
  if (skipHolidays && isUSHoliday(date)) {
    return false;
  }
  return true;
}

/**
 * Get the next trading day from a given date
 */
export function getNextMarketDay(date = getCurrentDate(), skipHolidays = true) {
  let nextDay = date.plus({ days: 1 });
  while (!isMarketDay(nextDay, skipHolidays)) {
    nextDay = nextDay.plus({ days: 1 });
  }
  return nextDay;
}

/**
 * Get reason why today is not a market day (for logging)
 */
export function getNonMarketDayReason(date = getCurrentDate()) {
  if (isWeekend(date)) {
    return date.weekday === 6 ? 'Saturday' : 'Sunday';
  }
  if (isUSHoliday(date)) {
    return 'US Market Holiday';
  }
  return null;
}

/**
 * Get all holidays for a given year
 */
export function getHolidaysForYear(year) {
  const holidays = [];
  for (const dateStr of US_HOLIDAYS) {
    if (dateStr.startsWith(String(year))) {
      holidays.push(dateStr);
    }
  }
  return holidays.sort();
}
