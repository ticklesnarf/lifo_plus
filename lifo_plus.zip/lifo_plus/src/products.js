// src/products.js
// Nado perpetual product definitions

export const PRODUCTS = {
  0:  { id: 0,  ticker: 'USDT0',              symbol: 'USDT0',    type: 'quote', minSize: 0n, sizeIncrement: 0n },
  2:  { id: 2,  ticker: 'BTC-PERP_USDT0',     symbol: 'BTC-PERP', type: 'perp',  minSize: 250_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  4:  { id: 4,  ticker: 'ETH-PERP_USDT0',     symbol: 'ETH-PERP', type: 'perp',  minSize: 1_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  8:  { id: 8,  ticker: 'SOL-PERP_USDT0',     symbol: 'SOL-PERP', type: 'perp',  minSize: 10_000_000_000_000_000n, sizeIncrement: 1_000_000_000_000_000n },
  10: { id: 10, ticker: 'XRP-PERP_USDT0',     symbol: 'XRP-PERP', type: 'perp',  minSize: 1_000_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000_000n },
  14: { id: 14, ticker: 'BNB-PERP_USDT0',     symbol: 'BNB-PERP', type: 'perp',  minSize: 1_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  16: { id: 16, ticker: 'HYPE-PERP_USDT0',    symbol: 'HYPE-PERP', type: 'perp', minSize: 10_000_000_000_000_000n, sizeIncrement: 1_000_000_000_000_000n },
  18: { id: 18, ticker: 'ZEC-PERP_USDT0',     symbol: 'ZEC-PERP', type: 'perp',  minSize: 1_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  20: { id: 20, ticker: 'MON-PERP_USDT0',     symbol: 'MON-PERP', type: 'perp',  minSize: 100_000_000_000_000_000n, sizeIncrement: 10_000_000_000_000_000n },
  22: { id: 22, ticker: 'FARTCOIN-PERP_USDT0', symbol: 'FARTCOIN-PERP', type: 'perp', minSize: 100_000_000_000_000_000n, sizeIncrement: 10_000_000_000_000_000n },
  24: { id: 24, ticker: 'SUI-PERP_USDT0',     symbol: 'SUI-PERP', type: 'perp',  minSize: 10_000_000_000_000_000n, sizeIncrement: 1_000_000_000_000_000n },
  26: { id: 26, ticker: 'AAVE-PERP_USDT0',    symbol: 'AAVE-PERP', type: 'perp', minSize: 1_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  28: { id: 28, ticker: 'XAUT-PERP_USDT0',    symbol: 'XAUT-PERP', type: 'perp', minSize: 100_000_000_000_000n, sizeIncrement: 10_000_000_000_000n },
  30: { id: 30, ticker: 'PUMP-PERP_USDT0',    symbol: 'PUMP-PERP', type: 'perp', minSize: 100_000_000_000_000_000n, sizeIncrement: 10_000_000_000_000_000n },
  32: { id: 32, ticker: 'TAO-PERP_USDT0',     symbol: 'TAO-PERP', type: 'perp',  minSize: 100_000_000_000_000n, sizeIncrement: 10_000_000_000_000n },
  34: { id: 34, ticker: 'XMR-PERP_USDT0',     symbol: 'XMR-PERP', type: 'perp',  minSize: 1_000_000_000_000_000n, sizeIncrement: 100_000_000_000_000n },
  36: { id: 36, ticker: 'LIT-PERP_USDT0',     symbol: 'LIT-PERP', type: 'perp',  minSize: 100_000_000_000_000_000n, sizeIncrement: 10_000_000_000_000_000n },
};

export function getProduct(productId) {
  return PRODUCTS[productId] || null;
}

export function getProductSymbol(productId) {
  const product = PRODUCTS[productId];
  return product ? product.symbol : `PRODUCT-${productId}`;
}

export function getPerpProducts() {
  return Object.values(PRODUCTS).filter(p => p.type === 'perp');
}

export function parseProductIds(str) {
  if (!str) return [];
  return str.split(',').map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n) && PRODUCTS[n]);
}
