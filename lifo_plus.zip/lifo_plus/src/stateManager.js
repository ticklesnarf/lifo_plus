// src/stateManager.js
import fs from 'fs';
import path from 'path';
import { log } from './logger.js';

/**
 * State Manager for persisting bot state across restarts.
 *
 * Manages three state files:
 * - .bot-state.json: Current position, entry price, TP zone status
 * - .zone-config.json: Adaptive timing configuration
 * - .market-data.json: Historical price data for learning
 */
export class StateManager {
  constructor(productId = null, basePath = process.cwd()) {
    this.basePath = basePath;
    this.productId = productId;

    // Use product-specific filenames if productId is provided
    const suffix = productId ? `-${productId}` : '';
    this.botStatePath = path.join(basePath, `.bot-state${suffix}.json`);
    this.zoneConfigPath = path.join(basePath, `.zone-config${suffix}.json`);
    this.marketDataPath = path.join(basePath, `.market-data${suffix}.json`);
  }

  // ==================== Bot State ====================

  /**
   * Default bot state structure
   */
  _defaultBotState() {
    return {
      version: 1,
      lastUpdated: null,
      position: {
        side: null,         // 'buy' or 'sell'
        entryPriceX18: null,
        entryTime: null,
        sizeX18: null,
      },
      tpZone: {
        active: false,
        peakProfitPct: 0,
        peakPriceX18: null,
        enteredAt: null,
      },
      lastZone: {
        side: null,
        flipTime: null,
      },
      stats: {
        totalTrades: 0,
        winningTrades: 0,
        totalPnlPct: 0,
      },
    };
  }

  /**
   * Load bot state from file
   */
  loadBotState() {
    try {
      if (fs.existsSync(this.botStatePath)) {
        const data = fs.readFileSync(this.botStatePath, 'utf8');
        const state = JSON.parse(data);
        log.info('Loaded bot state from disk', {
          hasPosition: state.position?.side != null,
          tpZoneActive: state.tpZone?.active,
        });
        return { ...this._defaultBotState(), ...state };
      }
    } catch (err) {
      log.warn('Failed to load bot state, using defaults', { error: err.message });
    }
    return this._defaultBotState();
  }

  /**
   * Save bot state to file
   */
  saveBotState(state) {
    try {
      state.lastUpdated = new Date().toISOString();
      const data = JSON.stringify(state, null, 2);
      fs.writeFileSync(this.botStatePath, data);
      log.debug('Saved bot state to disk');
    } catch (err) {
      log.error('Failed to save bot state', { error: err.message });
    }
  }

  /**
   * Clear bot state (reset to defaults)
   */
  clearBotState() {
    const defaultState = this._defaultBotState();
    this.saveBotState(defaultState);
    return defaultState;
  }

  // ==================== Zone Config ====================

  /**
   * Default zone configuration
   */
  _defaultZoneConfig() {
    return {
      version: 1,
      lastUpdated: null,
      // Offset in minutes from default times (can be + or -)
      marketOpenOffset: 0,
      marketCloseOffset: 0,
      // Confidence from adaptive learning
      confidence: 0,
      // Last analysis metadata
      lastAnalysis: {
        timestamp: null,
        dataPointsUsed: 0,
        avgProfitPct: 0,
      },
    };
  }

  /**
   * Load zone configuration
   */
  loadZoneConfig() {
    try {
      if (fs.existsSync(this.zoneConfigPath)) {
        const data = fs.readFileSync(this.zoneConfigPath, 'utf8');
        const config = JSON.parse(data);
        log.info('Loaded zone config from disk', {
          openOffset: config.marketOpenOffset,
          closeOffset: config.marketCloseOffset,
        });
        return { ...this._defaultZoneConfig(), ...config };
      }
    } catch (err) {
      log.warn('Failed to load zone config, using defaults', { error: err.message });
    }
    return this._defaultZoneConfig();
  }

  /**
   * Save zone configuration
   */
  saveZoneConfig(config) {
    try {
      config.lastUpdated = new Date().toISOString();
      const data = JSON.stringify(config, null, 2);
      fs.writeFileSync(this.zoneConfigPath, data);
      log.info('Saved zone config to disk', {
        openOffset: config.marketOpenOffset,
        closeOffset: config.marketCloseOffset,
      });
    } catch (err) {
      log.error('Failed to save zone config', { error: err.message });
    }
  }

  // ==================== Market Data ====================

  /**
   * Load market data history
   */
  loadMarketData() {
    try {
      if (fs.existsSync(this.marketDataPath)) {
        const data = fs.readFileSync(this.marketDataPath, 'utf8');
        const marketData = JSON.parse(data);
        log.info('Loaded market data from disk', {
          dataPoints: marketData.history?.length || 0,
        });
        return marketData;
      }
    } catch (err) {
      log.warn('Failed to load market data, starting fresh', { error: err.message });
    }
    return { version: 1, history: [] };
  }

  /**
   * Save market data
   */
  saveMarketData(marketData) {
    try {
      marketData.lastUpdated = new Date().toISOString();
      const data = JSON.stringify(marketData, null, 2);
      fs.writeFileSync(this.marketDataPath, data);
      log.debug('Saved market data to disk', {
        dataPoints: marketData.history?.length || 0,
      });
    } catch (err) {
      log.error('Failed to save market data', { error: err.message });
    }
  }

  /**
   * Append a data point to market history
   */
  appendMarketDataPoint(dataPoint) {
    const marketData = this.loadMarketData();

    marketData.history.push({
      ...dataPoint,
      recordedAt: new Date().toISOString(),
    });

    this.saveMarketData(marketData);
    return marketData;
  }

  /**
   * Update the last data point (e.g., when closing a position)
   */
  updateLastMarketDataPoint(updates) {
    const marketData = this.loadMarketData();

    if (marketData.history.length > 0) {
      const lastPoint = marketData.history[marketData.history.length - 1];
      Object.assign(lastPoint, updates, { updatedAt: new Date().toISOString() });
      this.saveMarketData(marketData);
    }

    return marketData;
  }

  /**
   * Trim market data older than N days
   */
  trimOldMarketData(days) {
    const marketData = this.loadMarketData();
    const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000);

    const originalCount = marketData.history.length;
    marketData.history = marketData.history.filter(point => {
      const pointTime = new Date(point.recordedAt).getTime();
      return pointTime >= cutoffTime;
    });

    const trimmedCount = originalCount - marketData.history.length;
    if (trimmedCount > 0) {
      log.info('Trimmed old market data', {
        trimmedCount,
        remaining: marketData.history.length,
        cutoffDays: days,
      });
      this.saveMarketData(marketData);
    }

    return marketData;
  }

  /**
   * Get market data for analysis (last N days)
   */
  getRecentMarketData(days) {
    const marketData = this.loadMarketData();
    const cutoffTime = Date.now() - (days * 24 * 60 * 60 * 1000);

    return marketData.history.filter(point => {
      const pointTime = new Date(point.recordedAt).getTime();
      return pointTime >= cutoffTime;
    });
  }
}

// Export singleton instance
export const stateManager = new StateManager();
