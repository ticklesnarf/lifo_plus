// src/nadoSubscriptions.js
import EventEmitter from 'events';

import { config } from './config.js';
import { log, safeStringify } from './logger.js';
import { x18ToDecimalString } from './utils.js';

function getQueryEndpoint() {
  if (config.network === 'mainnet') return 'https://gateway.prod.nado.xyz/v1/query';
  return 'https://gateway.test.nado.xyz/v1/query';
}

export function addressToSubaccountBytes32(address, subaccountName) {
  const addr = address.toLowerCase().replace(/^0x/, '');
  if (addr.length !== 40) throw new Error(`Invalid address: ${address}`);
  const nameBytes = Buffer.from(subaccountName, 'utf8');
  if (nameBytes.length > 12) throw new Error('SUBACCOUNT_NAME must be <= 12 bytes');
  const padded = Buffer.concat([nameBytes, Buffer.alloc(12 - nameBytes.length, 0)]);
  return `0x${addr}${padded.toString('hex')}`;
}

async function getEndpointAddress() {
  const url = `${getQueryEndpoint()}?type=contracts`;
  const res = await fetch(url, {
    headers: {
      'Accept-Encoding': 'gzip, deflate',
    },
  });
  if (!res.ok) throw new Error(`Failed to fetch contracts: ${res.status}`);
  const data = await res.json();
  return data.data?.endpoint_addr || data.endpoint;
}

async function fetchMarketPrice(productId, stats) {
  const url = `${getQueryEndpoint()}?type=market_price&product_id=${productId}`;
  
  stats.totalQueries++;
  
  const res = await fetch(url, {
    headers: {
      'Accept-Encoding': 'gzip, deflate',
    },
  });
  
  if (res.status === 429) {
    stats.rateLimitHits++;
    throw new Error('Rate limit (429) - backing off');
  }
  
  if (!res.ok) throw new Error(`Failed to fetch market_price: ${res.status}`);
  const data = await res.json();
  
  if (data.status !== 'success' || !data.data) {
    throw new Error(`Invalid market_price response: ${safeStringify(data)}`);
  }

  return {
    bidPriceX18: data.data.bid_x18,
    askPriceX18: data.data.ask_x18,
  };
}

export class NadoSubscriptions extends EventEmitter {
  constructor({ productId, productIds, address, subaccountName, walletClient, chainId }) {
    super();
    // Support both single productId and array of productIds
    this.productIds = productIds || [productId];
    this.productId = productId; // Keep for backwards compatibility
    this.address = address;
    this.subaccountName = subaccountName;
    this.subaccount = addressToSubaccountBytes32(address, subaccountName);
    this.walletClient = walletClient;
    this.chainId = chainId;

    this._pollInterval = null;
    this._running = false;
    this._endpointAddress = null;

    // BBO per product
    this.bboByProduct = new Map();
    this.bbo = null; // Keep for backwards compatibility (primary product)

    this._stats = {
      totalQueries: 0,
      rateLimitHits: 0,
      consecutiveErrors: 0,
      lastStatsLogMs: Date.now(),
    };
    this._currentBackoffMs = 0;
  }

  async start() {
    try {
      this._endpointAddress = await getEndpointAddress();
      log.info('Fetched endpoint address', { endpoint: this._endpointAddress });
    } catch (err) {
      log.error('Failed to get endpoint address', { error: err.message });
      throw err;
    }

    this._running = true;
    this._startPolling();
    log.info('REST API polling started', {
      productIds: this.productIds,
      pollIntervalMs: config.restPollIntervalMs || 1500,
      dryRun: config.dryRun,
    });
  }

  stop() {
    this._running = false;
    if (this._pollInterval) {
      clearInterval(this._pollInterval);
      this._pollInterval = null;
    }
    log.info('REST API polling stopped');
  }

  _startPolling() {
    const pollIntervalMs = config.restPollIntervalMs || 1500;

    this._poll();

    this._pollInterval = setInterval(() => {
      if (this._running) {
        this._poll();
      }
    }, pollIntervalMs);
  }

  async _poll() {
    if (this._currentBackoffMs > 0) {
      await new Promise(r => setTimeout(r, this._currentBackoffMs));
    }

    try {
      await this._pollBBO();
      this._stats.consecutiveErrors = 0;
      this._currentBackoffMs = 0;
    } catch (err) {
      this._stats.consecutiveErrors++;
      
      if (err.message.includes('429') || this._stats.consecutiveErrors >= 3) {
        this._currentBackoffMs = Math.min(
          (this._currentBackoffMs || 1000) * 2,
          30000
        );
        log.warn('API error - backing off', { 
          error: err.message, 
          backoffMs: this._currentBackoffMs,
          consecutiveErrors: this._stats.consecutiveErrors,
        });
      } else {
        log.warn('BBO poll error', { error: err.message });
      }
    }

    this._logStatsIfDue();
  }

  _logStatsIfDue() {
    const now = Date.now();
    const intervalMs = 60000;
    if (now - this._stats.lastStatsLogMs >= intervalMs) {
      const elapsedMin = (now - this._stats.lastStatsLogMs) / 60000;
      const qpm = Math.round(this._stats.totalQueries / elapsedMin);
      
      log.info('API stats (last minute)', {
        queriesPerMin: qpm,
        totalQueries: this._stats.totalQueries,
        rateLimitHits: this._stats.rateLimitHits,
        currentBackoffMs: this._currentBackoffMs,
      });
      
      this._stats.totalQueries = 0;
      this._stats.rateLimitHits = 0;
      this._stats.lastStatsLogMs = now;
    }
  }

  async _pollBBO() {
    // Poll all products
    for (const productId of this.productIds) {
      try {
        const { bidPriceX18, askPriceX18 } = await fetchMarketPrice(productId, this._stats);

        const bid = x18ToDecimalString(bidPriceX18);
        const ask = x18ToDecimalString(askPriceX18);

        const bbo = {
          productId,
          timestampNs: Date.now() * 1_000_000,
          bidPriceX18,
          askPriceX18,
          bid,
          ask,
        };

        this.bboByProduct.set(productId, bbo);

        // Keep backwards compatibility - primary product
        if (productId === this.productId) {
          this.bbo = bbo;
        }

        this.emit('bbo', bbo);
      } catch (err) {
        log.warn('BBO poll error for product', { productId, error: err.message });
      }
    }
  }

  getBbo(productId) {
    return this.bboByProduct.get(productId) || null;
  }
}
