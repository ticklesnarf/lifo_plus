// src/logger.js
import { config } from './config.js';

const levels = ['debug', 'info', 'warn', 'error'];
const levelRank = Object.fromEntries(levels.map((l, i) => [l, i]));
const minRank = levelRank[config.logLevel] ?? levelRank.info;

export function safeStringify(obj) {
  try {
    return JSON.stringify(obj, (_k, v) => (typeof v === 'bigint' ? v.toString() : v));
  } catch (e) {
    try { return String(obj); } catch { return '[unstringifiable]'; }
  }
}

function fmt(obj) {
  if (obj === undefined) return '';
  if (typeof obj === 'string') return obj;
  return safeStringify(obj);
}

function logAt(level, msg, meta) {
  if ((levelRank[level] ?? 99) < minRank) return;
  const ts = new Date().toISOString();
  const line = `[${ts}] ${level.toUpperCase()} ${msg}${meta !== undefined ? ' ' + fmt(meta) : ''}`;
  // eslint-disable-next-line no-console
  console.log(line);
}

export const log = {
  debug: (m, meta) => logAt('debug', m, meta),
  info: (m, meta) => logAt('info', m, meta),
  warn: (m, meta) => logAt('warn', m, meta),
  error: (m, meta) => logAt('error', m, meta),
};
