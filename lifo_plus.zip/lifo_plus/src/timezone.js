// src/timezone.js
import { DateTime } from 'luxon';

/**
 * Timezone utilities for the Bitcoin9to5 strategy.
 * All times are handled in America/New_York (ET) timezone.
 */

// Default configuration - will be overridden by config.js imports
let _config = {
  timezone: 'America/New_York',
  marketOpenHour: 9,
  marketOpenMinute: 29,
  marketCloseHour: 16,
  marketCloseMinute: 1,
};

/**
 * Set the timezone configuration (called from config.js)
 */
export function setTimezoneConfig(cfg) {
  _config = {
    timezone: cfg.timezone || 'America/New_York',
    marketOpenHour: cfg.marketOpenHour ?? 9,
    marketOpenMinute: cfg.marketOpenMinute ?? 29,
    marketCloseHour: cfg.marketCloseHour ?? 16,
    marketCloseMinute: cfg.marketCloseMinute ?? 1,
  };
}

/**
 * Get current time in configured timezone
 */
export function nowInTimezone() {
  return DateTime.now().setZone(_config.timezone);
}

/**
 * Get market open time for a given date
 */
export function getMarketOpenTime(date = nowInTimezone()) {
  return date.set({
    hour: _config.marketOpenHour,
    minute: _config.marketOpenMinute,
    second: 0,
    millisecond: 0,
  });
}

/**
 * Get market close time for a given date
 */
export function getMarketCloseTime(date = nowInTimezone()) {
  return date.set({
    hour: _config.marketCloseHour,
    minute: _config.marketCloseMinute,
    second: 0,
    millisecond: 0,
  });
}

/**
 * Determine if currently in US market hours (SHORT zone)
 * Market hours: 9:29 AM - 4:01 PM ET on weekdays
 */
export function isMarketHours(date = nowInTimezone()) {
  const marketOpen = getMarketOpenTime(date);
  const marketClose = getMarketCloseTime(date);
  return date >= marketOpen && date < marketClose;
}

/**
 * Get desired position side based on current time zone
 * SHORT (sell) during market hours, LONG (buy) otherwise
 */
export function getZoneSide(date = nowInTimezone()) {
  return isMarketHours(date) ? 'sell' : 'buy';
}

/**
 * Get the current zone name for logging
 */
export function getZoneName(date = nowInTimezone()) {
  return isMarketHours(date) ? 'MARKET_HOURS' : 'OFF_HOURS';
}

/**
 * Calculate milliseconds until next zone flip
 */
export function msUntilNextZoneFlip(date = nowInTimezone()) {
  const inMarket = isMarketHours(date);

  let target;
  if (inMarket) {
    // In market hours -> wait for close
    target = getMarketCloseTime(date);
  } else {
    // Outside market hours -> wait for open
    target = getMarketOpenTime(date);
    // If market open already passed today, target tomorrow's open
    if (target <= date) {
      target = target.plus({ days: 1 });
    }
  }

  const diff = target.diff(date);
  return Math.max(0, diff.as('milliseconds'));
}

/**
 * Get next zone flip time as DateTime
 */
export function getNextZoneFlipTime(date = nowInTimezone()) {
  const ms = msUntilNextZoneFlip(date);
  return date.plus({ milliseconds: ms });
}

/**
 * Get next zone flip info
 */
export function getNextZoneFlipInfo(date = nowInTimezone()) {
  const inMarket = isMarketHours(date);
  const nextFlipTime = getNextZoneFlipTime(date);
  const msUntil = msUntilNextZoneFlip(date);

  return {
    currentZone: inMarket ? 'MARKET_HOURS' : 'OFF_HOURS',
    currentSide: inMarket ? 'sell' : 'buy',
    nextZone: inMarket ? 'OFF_HOURS' : 'MARKET_HOURS',
    nextSide: inMarket ? 'buy' : 'sell',
    nextFlipTime: nextFlipTime.toISO(),
    nextFlipTimeFormatted: nextFlipTime.toFormat('yyyy-MM-dd HH:mm:ss ZZZZ'),
    msUntilFlip: msUntil,
    minutesUntilFlip: Math.round(msUntil / 60000),
    hoursUntilFlip: Math.round(msUntil / 3600000 * 10) / 10,
  };
}

/**
 * Format a DateTime for logging
 */
export function formatTime(date = nowInTimezone()) {
  return date.toFormat('yyyy-MM-dd HH:mm:ss ZZZZ');
}

/**
 * Get hours until next zone flip (for TP zone decision)
 */
export function hoursUntilNextZoneFlip(date = nowInTimezone()) {
  return msUntilNextZoneFlip(date) / 3600000;
}
