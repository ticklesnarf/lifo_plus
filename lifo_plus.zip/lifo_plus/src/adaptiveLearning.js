// src/adaptiveLearning.js
import { DateTime } from 'luxon';
import { config } from './config.js';
import { log } from './logger.js';
import { StateManager } from './stateManager.js';

/**
 * AdaptiveLearning - Analyzes historical data to optimize zone flip times
 *
 * The system:
 * 1. Records price data at each zone flip
 * 2. Tracks P&L for each trade
 * 3. Analyzes optimal entry/exit times based on historical performance
 * 4. Suggests timing adjustments (offsets from default times)
 */
export class AdaptiveLearning {
  constructor() {
    this.stateManager = new StateManager();
  }

  /**
   * Run daily optimization analysis
   * Called via cron at midnight ET
   */
  async runDailyOptimization() {
    if (!config.enableAdaptiveLearning) {
      log.debug('Adaptive learning disabled');
      return null;
    }

    log.info('Running daily adaptive learning optimization');

    try {
      // Trim old data
      this.stateManager.trimOldMarketData(config.learningLookbackDays);

      // Load recent data
      const recentData = this.stateManager.getRecentMarketData(config.learningLookbackDays);

      if (recentData.length < 7) {
        log.info('Insufficient data for optimization', {
          dataPoints: recentData.length,
          required: 7,
        });
        return null;
      }

      // Analyze data
      const analysis = this._analyzeTradePerformance(recentData);

      // Calculate optimal offsets
      const optimalOffsets = this._calculateOptimalOffsets(analysis);

      // Save updated zone config
      const zoneConfig = this.stateManager.loadZoneConfig();
      zoneConfig.marketOpenOffset = optimalOffsets.openOffset;
      zoneConfig.marketCloseOffset = optimalOffsets.closeOffset;
      zoneConfig.confidence = optimalOffsets.confidence;
      zoneConfig.lastAnalysis = {
        timestamp: new Date().toISOString(),
        dataPointsUsed: recentData.length,
        avgProfitPct: analysis.avgProfitPct,
        winRate: analysis.winRate,
      };

      this.stateManager.saveZoneConfig(zoneConfig);

      log.info('Adaptive learning optimization complete', {
        openOffset: optimalOffsets.openOffset + ' min',
        closeOffset: optimalOffsets.closeOffset + ' min',
        confidence: (optimalOffsets.confidence * 100).toFixed(1) + '%',
        avgProfitPct: analysis.avgProfitPct.toFixed(4) + '%',
        winRate: (analysis.winRate * 100).toFixed(1) + '%',
      });

      return optimalOffsets;
    } catch (err) {
      log.error('Adaptive learning failed', { error: err.message });
      return null;
    }
  }

  /**
   * Analyze trade performance from historical data
   */
  _analyzeTradePerformance(data) {
    const completeTrades = data.filter(d => d.type === 'exit' && d.pnlPct !== undefined);

    if (completeTrades.length === 0) {
      return {
        totalTrades: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        avgProfitPct: 0,
        marketOpenTrades: [],
        marketCloseTrades: [],
      };
    }

    const wins = completeTrades.filter(t => t.pnlPct > 0).length;
    const losses = completeTrades.length - wins;
    const totalPnl = completeTrades.reduce((sum, t) => sum + (t.pnlPct || 0), 0);

    // Group trades by zone transition type
    const entryData = data.filter(d => d.type === 'entry');
    const marketOpenTrades = entryData.filter(d => d.zone === 'MARKET_HOURS');
    const marketCloseTrades = entryData.filter(d => d.zone === 'OFF_HOURS');

    return {
      totalTrades: completeTrades.length,
      wins,
      losses,
      winRate: completeTrades.length > 0 ? wins / completeTrades.length : 0,
      avgProfitPct: completeTrades.length > 0 ? totalPnl / completeTrades.length : 0,
      marketOpenTrades,
      marketCloseTrades,
    };
  }

  /**
   * Calculate optimal timing offsets based on analysis
   *
   * Strategy: Analyze trades by entry time and find patterns where
   * earlier or later entries yielded better results.
   */
  _calculateOptimalOffsets(analysis) {
    // Default: no offset changes (conservative approach)
    let openOffset = 0;
    let closeOffset = 0;
    let confidence = 0;

    // Need sufficient data to make adjustments
    if (analysis.totalTrades < 10) {
      return { openOffset, closeOffset, confidence };
    }

    // Analyze market open entries (SHORT positions)
    if (analysis.marketOpenTrades.length >= 5) {
      const openAnalysis = this._analyzeEntryTiming(analysis.marketOpenTrades, 'open');
      if (openAnalysis.confidence > 0.6) {
        openOffset = openAnalysis.suggestedOffset;
      }
    }

    // Analyze market close entries (LONG positions)
    if (analysis.marketCloseTrades.length >= 5) {
      const closeAnalysis = this._analyzeEntryTiming(analysis.marketCloseTrades, 'close');
      if (closeAnalysis.confidence > 0.6) {
        closeOffset = closeAnalysis.suggestedOffset;
      }
    }

    // Overall confidence based on data quality and win rate
    confidence = Math.min(1, analysis.winRate + (analysis.totalTrades / 100));

    // Clamp offsets to reasonable range (-15 to +15 minutes)
    openOffset = Math.max(-15, Math.min(15, openOffset));
    closeOffset = Math.max(-15, Math.min(15, closeOffset));

    return { openOffset, closeOffset, confidence };
  }

  /**
   * Analyze entry timing for a set of trades
   *
   * Looks for patterns in entry time vs. subsequent price movement
   */
  _analyzeEntryTiming(trades, type) {
    // Simplified analysis: calculate average entry time offset from scheduled time
    // and correlate with trade success

    // For now, use a simple heuristic based on overall performance
    // In a more sophisticated version, this would do statistical analysis

    const successfulTrades = trades.filter(t => {
      // Find corresponding exit
      return true; // Placeholder - would need to match entries with exits
    });

    // Default: no adjustment with low confidence
    return {
      suggestedOffset: 0,
      confidence: 0.5,
    };
  }

  /**
   * Get current zone config with applied offsets
   */
  getOptimizedZoneConfig() {
    const zoneConfig = this.stateManager.loadZoneConfig();

    // Only apply offsets if confidence is sufficient
    if (zoneConfig.confidence >= 0.7) {
      return {
        marketOpenOffset: zoneConfig.marketOpenOffset,
        marketCloseOffset: zoneConfig.marketCloseOffset,
        applied: true,
      };
    }

    return {
      marketOpenOffset: 0,
      marketCloseOffset: 0,
      applied: false,
    };
  }

  /**
   * Get learning statistics for display
   */
  getStats() {
    const zoneConfig = this.stateManager.loadZoneConfig();
    const recentData = this.stateManager.getRecentMarketData(config.learningLookbackDays);

    return {
      dataPoints: recentData.length,
      lookbackDays: config.learningLookbackDays,
      currentOpenOffset: zoneConfig.marketOpenOffset,
      currentCloseOffset: zoneConfig.marketCloseOffset,
      confidence: zoneConfig.confidence,
      lastAnalysis: zoneConfig.lastAnalysis,
    };
  }
}

// Export singleton instance
export const adaptiveLearning = new AdaptiveLearning();
