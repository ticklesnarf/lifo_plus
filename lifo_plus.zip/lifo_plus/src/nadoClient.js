// src/nadoClient.js
import { createNadoClient } from '@nadohq/client';
import { privateKeyToAccount } from 'viem/accounts';
import { createWalletClient, createPublicClient, http } from 'viem';
import { ink } from 'viem/chains';

import { config } from './config.js';
import { log } from './logger.js';

function getChainAndMode() {
  // As of the reference implementation, we default to Ink mainnet.
  // If you need testnet support, set NADO_NETWORK=testnet AND provide RPC_URL.
  if (config.network === 'mainnet') {
    return { chain: ink, mode: 'inkMainnet' };
  }
  // Minimal testnet support: user must provide RPC_URL and a compatible Nado mode.
  // NOTE: If your SDK expects a different mode string, adjust here.
  const rpcUrl = process.env.RPC_URL;
  if (!rpcUrl) {
    throw new Error('For testnet, set RPC_URL env var (Ink testnet RPC endpoint).');
  }
  const testnetChain = {
    id: 763373,
    name: 'Ink Testnet',
    nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
    rpcUrls: {
      default: { http: [rpcUrl] },
      public: { http: [rpcUrl] },
    },
  };
  return { chain: testnetChain, mode: 'inkTestnet' };
}

export function createClients() {
  const { chain, mode } = getChainAndMode();

  const account = privateKeyToAccount(config.privateKey);

  const rpcUrl = process.env.RPC_URL;
  const transport = rpcUrl ? http(rpcUrl) : http();

  const walletClient = createWalletClient({
    account,
    chain,
    transport,
  });

  const publicClient = createPublicClient({
    chain,
    transport,
  });

  const nadoClient = createNadoClient(mode, { walletClient, publicClient });

  const subaccount = {
    subaccountOwner: account.address,
    subaccountName: config.subaccountName,
  };

  log.info('Initialized Nado client', {
    network: config.network,
    mode,
    chainId: chain.id,
    address: account.address,
    subaccountName: config.subaccountName,
    productId: config.productId,
  });

  return { nadoClient, walletClient, publicClient, account, subaccount, chainId: chain.id };
}

/**
 * Safely convert a value to BigInt, handling scientific notation and very large numbers.
 */
function safeToBigInt(value) {
  if (value === null || value === undefined) return 0n;
  if (typeof value === 'bigint') return value;
  
  let str = String(value);
  
  // Handle scientific notation (e.g., "1.5e+21" or "-8.3e21")
  if (str.includes('e') || str.includes('E')) {
    const [mantissa, exp] = str.toLowerCase().split('e');
    const exponent = parseInt(exp, 10);
    const [intPart, decPart = ''] = mantissa.replace('-', '').split('.');
    const isNegative = mantissa.startsWith('-');
    
    // Combine integer and decimal parts
    const digits = intPart + decPart;
    const zerosToAdd = exponent - decPart.length;
    
    let result;
    if (zerosToAdd >= 0) {
      result = digits + '0'.repeat(zerosToAdd);
    } else {
      // Exponent is smaller than decimal places - truncate
      result = digits.slice(0, digits.length + zerosToAdd) || '0';
    }
    
    return BigInt(isNegative ? '-' + result : result);
  }
  
  // Handle regular numbers/strings - remove any decimal part
  if (str.includes('.')) {
    str = str.split('.')[0];
  }
  
  return BigInt(str || '0');
}

/**
 * Pulls a simplified view of subaccount state for one perp product + quote collateral.
 */
export async function getSubaccountState(nadoClient, subaccount, productId) {
  const summary = await nadoClient.subaccount.getSubaccountSummary(subaccount);

  const perp = summary.balances.find((b) => b.productId === productId);
  const quote = summary.balances.find((b) => b.productId === 0);

  const positionAmountX18 = safeToBigInt(perp?.amount);
  const vQuoteX18 = safeToBigInt(perp?.vQuoteBalance);
  const collateralX18 = safeToBigInt(quote?.amount);

  return {
    exists: summary.exists,
    health: summary.health,
    positionAmountX18,
    vQuoteX18,
    collateralX18,
  };
}
